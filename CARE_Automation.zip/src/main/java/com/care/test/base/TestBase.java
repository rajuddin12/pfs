package com.care.test.base;

import java.io.File;
import java.lang.reflect.Method;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.care.excel.operations.ReadExcel;
import com.care.reporting.ExecutionLog;
import com.care.reporting.ExtentManager;
import com.care.reporting.ExtentTestManager;
import com.care.reporting.ReportScreenshot;
import com.care.utility.DateTimeHelper;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class TestBase  {

	public static WebDriver driver = null;
	private static String driverPath = ".\\Drivers\\";
	
	
	public static String appURL = "";
	
	public static String adminUserName ;
	public static String adminPass ;
	public static String nonAdminUserName ;
	public static String nonAdminPass ;
	public static String noGroupUserName ;
	public static String noGroupPass ;
	public static String browser = "";
	public static String path;
	public static String sheetName;
	public static String forecast_CreatedBy_adminUserName;
	public static String forecast_CreatedBy_NonadminUserName; 	
	public static String curentPageID; 	
	public static Boolean TestClassStatus; 	
	public static Boolean TestCaseStatus;
	public static ExtentReports report = new ExtentReports(System.getProperty("user.dir") + "\\TestReport\\Comcast_Test-Automaton-Report_" + DateTimeHelper.getCurrentDateTime() + ".html");;
	
	public void navigateToScreen() {
		ExecutionLog.log("Test Base Screen");
		// Overwrite this method
	}

	public static WebDriver getDriver() {
		return driver;
	}
	
	@BeforeClass(alwaysRun=true)
	public void TestClassStatusController() {
		TestClassStatus = true;// Controlled through TestClassStatus() method of each @Test Class
	}
	
	@BeforeMethod(alwaysRun=true)
	public void TestCaseStatusController() {
		TestCaseStatus  = true;// Controlled through ExecutionLog
	}

	// Initialize the credentials and URLs
	public static void initSession(){
		try {
			String filePath = System.getProperty("user.dir") + File.separator + "\\CareTestData.xlsx";
			browser				= ReadExcel.getCellData(1, 1, "Login", filePath);
			appURL				= ReadExcel.getCellData(2, 1, "Login", filePath);
			adminUserName 		= ReadExcel.getCellData(3, 1, "Login", filePath);
			adminPass 			= ReadExcel.getCellData(4, 1, "Login", filePath);
			nonAdminUserName 	= ReadExcel.getCellData(5, 1, "Login", filePath);
			nonAdminPass 		= ReadExcel.getCellData(6, 1, "Login", filePath);
			noGroupUserName 	= ReadExcel.getCellData(7, 1, "Login", filePath);
			noGroupPass 		= ReadExcel.getCellData(8, 1, "Login", filePath);
			forecast_CreatedBy_adminUserName 	= "AUT_Forecast_adminUserName" + DateTimeHelper.getCurrentDateTime();
			forecast_CreatedBy_NonadminUserName 	= "AUT_Forecast_NonadminUserName" + DateTimeHelper.getCurrentDateTime();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Launch browser along with application URL as defined in test data file
	 * i.e. launch with default values
	 * @return Web-driver instance 
	 */
	public static WebDriver setDriver() {
		return setDriver(browser, appURL);
		
	}
	
	/**
	 * Launch browser along with following provided parameters 
	 * @param browserType (if empty initialize as defined in test data file)
	 * @param appURL (if empty initialize as defined in test data file)
	 * @return web-driver instance
	 */
	public static WebDriver setDriver(String browserType, String appURL) {
		initSession();
		
		if(browserType.equals(""))
			browserType = browser;

		if(appURL.equals(""))
			appURL = TestBase.appURL;
		
		switch (browserType.toLowerCase()) {
		case "chrome":
			driver = initChromeDriver(appURL);
			break;
		case "firefox":
			driver = initFirefoxDriver(appURL);
			break;
		default:
			driver = initChromeDriver(appURL);
		}
		return driver;
	}

	private static WebDriver initChromeDriver(String appURL) {
		ExecutionLog.log("[INFO] Launching Google Chrome with "+ appURL);
		System.setProperty("webdriver.chrome.driver", driverPath + "chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(appURL);
		return driver;
	}

	private static WebDriver initFirefoxDriver(String appURL) {
		ExecutionLog.log("[INFO] Launching Firefox with "+ appURL);
		System.setProperty("webdriver.gecko.driver", driverPath + "geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.navigate().to(appURL);
		return driver;
	}

	@BeforeMethod(alwaysRun=true)
	public void beforeEveryTest(Method method) {
		Test test = method.getAnnotation(Test.class);
		ExtentTestManager.startTest(test.description());		
	}
		
	@AfterMethod(alwaysRun=true)
	protected void afterMethod(ITestResult result) throws Exception {		
		LogStatus status = ExtentTestManager.getTest().getRunStatus();
		if (result.getStatus() == ITestResult.FAILURE) {
			TestBase.TestClassStatus = false;
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			ExtentTestManager.getTest().log(LogStatus.INFO, org.apache.commons.lang3.exception.ExceptionUtils.getStackTrace(result.getThrowable()));
			ExtentTestManager.getTest().log(LogStatus.FAIL, "Test Case Failed" + result.getThrowable() );
			ExecutionLog.log(result.getThrowable().getStackTrace() + "");
		} else if (result.getStatus() == ITestResult.SKIP) {
			ExtentTestManager.getTest().log(LogStatus.SKIP, "Test Case Skipped" + result.getThrowable());
		} else {
			ExtentTestManager.getTest().log(LogStatus.PASS, "Test Case Passed");
		}
		
		ExtentManager.getReporter().endTest(ExtentTestManager.getTest());        
		ExtentManager.getReporter().flush();		
		report.flush();
	}

}
