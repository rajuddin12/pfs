package com.care.screens;

import static com.care.utility.CommonMethods.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import static com.care.screens.CommonScreen.*;
import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

public class CreateForecastScreen extends TestBase {

	public static String startMonth_value;
	public static String startYear_value;
	public static String endMonth_value;
	public static String endYear_value;
	
	String schemeName;
	String audienceSize;
	String responseRate;
	String minWeeklyResponse;
	String startDate;
	String endDate;
	String startDate_2;
	String endDate_2;

	
	
	
	
	// Initialize all the WebElements of DashboardScreen
	public CreateForecastScreen() {
			ExecutionLog.log("==========| CreateForecast Screen |==========");
			PageFactory.initElements(driver, this);
			audienceSize = "20";
			responseRate = "5";
			minWeeklyResponse = "10";
			startDate = "2018-11-10";
			startDate_2 = "11-10-2018";
			endDate = "2018-12-10"; // To Do: Make it dynamic with Forecast time period
			endDate_2 = "12-10-2018";
			
	}
	
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the Create Forecast Page 
	 */
																				public WebElement create_forecast;
	@FindBy(how = How.XPATH, using = "//label[@for='forecastType_Base']") 		public WebElement forecastType_Base;
	@FindBy(how = How.XPATH, using = "//label[@for='forecastType_Response']") 	public WebElement forecastType_Response;
	@FindBy(how = How.XPATH, using = "//input[@id='forecast']/../../div") 		public WebElement NameOfForecast_Label;
	@FindBy(id="forecast") 														public WebElement NameOfForecast_InputField;
	@FindBy(how = How.XPATH, using = "//select[@id='division']/../../label") 	public WebElement Division_Label;
	@FindBy(id="division") 														public WebElement Division_DropDown;
	@FindBy(how = How.XPATH, using = "//select[@id='region']/../../label") 		public WebElement Region_Label;
	@FindBy(id="region") 														public WebElement Region_DropDown;
	@FindBy(how = How.XPATH, using = "//select[@id='low']/../../label") 		public WebElement LineOfWork_Label;
	@FindBy(id="low") 															public WebElement LineOfWork_DropDown;
	@FindBy(how = How.XPATH, using = "//select[@id='startMonth']/../../label")	public WebElement StartDate_Label;
																				public WebElement startMonth;
																				public WebElement startYear;
    @FindBy(how = How.XPATH, using = "//select[@id='endMonth']/../../label")	public WebElement EndDate_Label;
																				public WebElement endMonth;
																				public WebElement endYear;
	@FindBy(how = How.XPATH, using = "//select[@id='associatedGroup']/../../label")	public WebElement associatedGroup_Label;
																				public WebElement associatedGroup;
    @FindBy(how = How.XPATH, using = "//form[@action='/screenTwoForForecastTypeBase']//h4")		
    																			public WebElement CreateForecasteScreenTwoHeader;																				
	@FindBy(id = "CABLECARD")													public WebElement CABLECARD_CheckBox;
	@FindBy(id = "CDV")															public WebElement CDV;
	@FindBy(id = "HSD")															public WebElement HSD;
	@FindBy(id = "VIDEO")														public WebElement VIDEO;
	@FindBy(id = "lbl_CABLECARD")												public WebElement CABLECARD_Label;
	@FindBy(id = "isDefaultFactors")											public WebElement UseDefaultFactors_CheckBox;
																				public WebElement newForecastSubmit;	
	@FindBy(id = "lbl_2018")													public WebElement HistoricalLabel2018;
	@FindBy(id = "2018")														public WebElement Historical2018;
	@FindBy(how = How.XPATH, using = "//h5[text()='Add Scheme ']")				public WebElement txt_heading_addScheme;
	@FindBy(id = "schemeName")													public WebElement inp_schemeName;	
	@FindBy(id = "startDate")													public WebElement inp_startDate;
	@FindBy(id = "endDate")												    	public WebElement inp_endDate;
	@FindBy(id = "audienceSize")										    	public WebElement inp_audienceSize;
	@FindBy(id = "contactVolume")										    	public WebElement inp_ResponseRate;
	@FindBy(id = "minWeeklyResponse")									    	public WebElement inp_minWeeklyResponse;
	@FindBy(id = "poisson_Delayed_Standard")									public WebElement radio_Delayed_Standard;	
	@FindBy(how = How.XPATH, using = "//button[text()='Add Scheme']") 			public WebElement btn_AddScheme;
	@FindBy(how = How.XPATH, using = "//legend[text()='Response']") 			public WebElement txt_heading_Response;
	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Add New')]")      public WebElement link_addNewScheme;
	
	/**
	 * Creates a new forecast as per provided parameters
	 * @param forecastName
	 * @param forecastType
	 */
	public void createForecast(String forecastName, String forecastType) {
		startMonth_value = getCurrentMonth().substring(0, 3);
		startYear_value = getCurrentMonth().substring(3, 7);
		endMonth_value = getCurrentMonthPlus2Month().substring(0, 3);
		endYear_value = getCurrentMonthPlus2Month().substring(3, 7);
		
		ExecutionLog.log("==========| Started creating the forecast '" + forecastName + "' |==========");
		clickOn(create_forecast, "Create Forecast");
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
		
		if(forecastType.equalsIgnoreCase("Base")) {
			clickOn(forecastType_Base, "forecastType_Base");
					
		}else if (forecastType.equalsIgnoreCase("Response")) {
			clickOn(forecastType_Response, "forecastType_Response");
					
		}
		
		enterDataIn(NameOfForecast_InputField, forecastName, "Name-Of-Forecast Field");
		
		if(appURL.contains("qa")) {
			selectValueFromDropDown(Division_DropDown, "CENTRAL", "Division Name Drop Down");
			selectValueFromDropDown(Region_DropDown,   "CHICAGO", "Region Name Drop Down");
		} else {
			clickOn( getElement("CENTRAL-CHICAGO") , "CENTRAL-CHICAGO check Box");
			verifyCheckboxIsChecked(getElement("CENTRAL-CHICAGO"), "CENTRAL-CHICAGO check Box", true);
			
			clickOn( getElement("//input[contains(@class,'pvData') and @id ='CENTRAL-CHICAGO']") , "CENTRAL-CHICAGO check Box");
			verifyCheckboxIsChecked(getElement("CENTRAL-CHICAGO"), "CENTRAL-CHICAGO check Box", true);
		}
		
		
		selectValueFromDropDown(LineOfWork_DropDown, "PHONE", "Line-Of-Work Drop Down");
		// Month-Year selection(for Next two month) needs to be improved by creating the separate method
		selectValueFromDropDown(startMonth, startMonth_value, "select start Month");
		selectValueFromDropDown(startYear, startYear_value, "select start Year");
		selectValueFromDropDown(endMonth, endMonth_value, "select End Month");
		selectValueFromDropDown(endYear, endYear_value, "select End Year");
		//Non-Admin user does not has the associated group hence using exception handling
		try {
			selectValueFromDropDown(associatedGroup, "grp_Central", "associatedGroup Drop Down");

		} catch (Exception e) {
			// TODO: handle exception
		}
		clickOn(newForecastSubmit, "Next Button");
		
		if(forecastType.equalsIgnoreCase("Base"))
			selectCallTypes(forecastName);
		else if(forecastType.equalsIgnoreCase("Response"))
			addScheme("Scheme1");
					
	}
	
	/**
	 * Add a new screen by providing all the mandatory fields 
	 */
	public void addScheme(String name) {
		schemeName = name;
		ExecutionLog.log("Verifying user is on 'Add Scheme' window.");
		ensureVisibilityOf(txt_heading_addScheme, "Heading: Add Scheme");
		waitForSpinnerToDisappear();
		enterDataIn(inp_schemeName, schemeName, "Input Scheme Name");
		enterDataIn(inp_audienceSize, audienceSize, "Input Audience Size");
		enterDataIn(inp_ResponseRate, responseRate, "Input Response Rate");
		enterDataIn(inp_minWeeklyResponse, minWeeklyResponse, "Input Min. Weekly Response");
		clickOn(radio_Delayed_Standard, "Delayed Standard");
		enterDataUsingJS(inp_startDate, startDate, "Scheme start date");
		enterDataUsingJS(inp_endDate, endDate, "Scheme end date");
		
		clickOn(btn_AddScheme, "Button Add Scheme");
			
	}
	
	/**
	 * Verify user is on Forecast(Response) page 
	 */
	public void verifyResponseHeader() {
		ensureVisibilityOf(txt_heading_Response, "Heading: Response");
		
	}
	
	public void verifySchemeIsAdded() {
		verifySchemeIsAdded(schemeName, startDate_2, endDate_2, audienceSize, responseRate, minWeeklyResponse, "Delayed Standard");
	}
	
	/**
	 * Verify created Scheme
	 * @param schemeName : locator is created to verify scheme is under Response
	 * @param startDate
	 * @param endDate
	 * @param audienceSize
	 * @param responseRate
	 * @param weeklyResp
	 * @param distribution
	 */
	public void verifySchemeIsAdded(String schemeName, String startDate, String endDate, String audienceSize, String responseRate, String weeklyResp, String distribution) {
		ensureVisibilityOf(getElement("//legend[text()='Response']/following-sibling :: table//th[text()='Scheme']/../../following-sibling :: tbody//td[text()='" + schemeName + "']"), "Scheme Name");
		ensureVisibilityOf(getElement("//th[text()='Start Date']/../../following-sibling :: tbody/tr/td[text()='" + schemeName + "']/following-sibling :: td[text()='" + startDate + "']"),  "Start Date");
		ensureVisibilityOf(getElement("//th[text()='End Date']/../../following-sibling :: tbody/tr/td[text()='" + schemeName + "']/following-sibling :: td[text()='" + endDate + "']"),  "End Date");
		ensureVisibilityOf(getElement("//th[text()='Audience Size']/../../following-sibling :: tbody/tr/td[text()='" + schemeName + "']/following-sibling :: td[text()='" + audienceSize + "']"),  "Audience Size");
		ensureVisibilityOf(getElement("//th/span[text()='Respone Rate(%)']/../../../following-sibling :: tbody//td[text()='" + schemeName + "']/following-sibling :: td[4]/span[text()='" + responseRate+ " %']"),  "Response Rate");
		ensureVisibilityOf(getElement("//th[text()='Min. Weekly Response']/../../following-sibling :: tbody//td[text()='" + schemeName + "']/following-sibling :: td[text()='" + weeklyResp + "']"),  "Weekly Response");
		ensureVisibilityOf(getElement("//th[text()='Distribution']/../../following-sibling :: tbody//td[text()='" + schemeName + "']/following-sibling :: td[text()='" + distribution + "']"),  "Distribution");
		
	}
	
	/**
	 * Click on Add New to create a more Scheme
	 */
	public void clickOnAddNewLinkToCreateMoreScheme() {
		clickOn(link_addNewScheme, "Link Add New Scheme");		
		
	}
	/**
	 * Select all the call types
	 * @param ForecastName
	 */
	public void selectCallTypes(String forecastName) {
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
		ensureVisibilityOf(CreateForecasteScreenTwoHeader, forecastName+" at the Header of Screen-Two-Of-CreateForecast");
		clickOn(CABLECARD_CheckBox, "Cable Card Check Box");
		clickOn(CDV, "CDV Check Box");
		clickOn(HSD, "HSD Check Box");
		clickOn(VIDEO, "VIDEO Check Box");
		
		selectHistoricalPeriod();
		
		clickOn(newForecastSubmit, "Next Button");
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
		
		new PredictiveVariablesScreen();// initialize the current Page ID
		verifyForcastName(forecastName);
		ExecutionLog.log("===========| Forecast '" + forecastName + "' has been successfully created |==========");
		
	}
	
	/**
	 * Click on next button
	 */
	public void clickOnNextButton() {
		clickOn(newForecastSubmit, "Next Button");
		
	}
	
	public String getCurrentMonth() {
		DateFormat dateFormat = new SimpleDateFormat("MMMyyyy");
		Calendar cal = Calendar.getInstance();
		String time = "" + dateFormat.format(cal.getTime());
		return time;
	}
	
	public String getCurrentMonthPlus2Month() {
		DateFormat dateFormat = new SimpleDateFormat("MMMyyyy");
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.MONTH, 2);
		String time = "" + dateFormat.format(cal.getTime());
		return time;
	}
	public void selectHistoricalPeriod() {
		if(appURL.contains("qa")) {
			checkRadioBtn(getElement("2016"), "Historical check Box");
			checkRadioBtn(getElement("2017"), "Historical check Box");
			checkRadioBtn(getElement("2018"), "Historical check Box");
		}
	}
	
	/**
	 * Click on Create Forecast link
	 */
	public void clickOnCreateForecastLink() {
		clickOn(create_forecast, "Create Forecast link");
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
	}
	
	/**
	 * Verify following provided Response Type forecast name is present at top-left of the screen
	 * @param forcastName
	 */
	public void verifyResponseTypeForcastName(String forcastName) {
		ExecutionLog.log("Verifying Forcast name: " + forcastName + " is present at top-left of the screen.");
		verifyTextOf(getElement("//div[contains(@class, 'container')]/div/h4"), forcastName, "Forcast Name");

	}
	

	/**
	 * Verify following provided fields are present at top of the screen for Response type forecast
	 * @param type
	 * @param period
	 * @param divisionName
	 * @param regionName
	 * @param lineOfWork
	 */
	public void verifyForcastInfoAtScreenHeaderForResponseTypeForecast(String type, String period, String divisionName, String regionName, String lineOfWork) {
		ExecutionLog.log("Verifying All the Headers present are in read-only mode as they are under 'p' tag (read only tag).");
		ExecutionLog.log("Verifying Forcast Type: "+ type +" is present at screen.");
		verifyTextOf(getElement("//p/strong[text()='Forecast Type:']/../following-sibling :: p"), type, "Forcast Type");
		ExecutionLog.log("Verifying Forcast Period: "+ period +" is present at screen.");
		verifyTextOf(getElement("//p/strong[text()='Forecast Period:']/../following-sibling :: p"), period, "Forcast Period");
		ExecutionLog.log("Verifying Division Name: "+ divisionName +" is present at screen.");
		verifyTextOf(getElement("//p/strong[text()='Division Name:']/../following-sibling :: p"), divisionName, "Division Name");
		ExecutionLog.log("Verifying Region Name: "+ regionName +" is present at screen.");
		verifyTextOf(getElement("//p/strong[text()='Region Name:']/../following-sibling :: p"), regionName, "Forcast Region");
		ExecutionLog.log("Verifying Line Of Work: "+ lineOfWork +" is present at screen.");
		verifyTextOf(getElement("//p/strong[text()='Line of Work:']/../following-sibling :: p"), lineOfWork, "Line Of Work");
		ExecutionLog.log("Verified that all the Headers present are in read-only mode as they under 'p' tag (read only tag).");

	}
	
}
