package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

import static com.care.utility.CommonMethods.*;

public class HolidayScreen extends TestBase {

	// Initialize all the WebElements of DashboardScreen
	public HolidayScreen() {
			ExecutionLog.log("==========| Holiday Screen |==========");
			curentPageID = "holidayFactorForm";
			PageFactory.initElements(driver, this);
	}
	
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the Holiday Screen 
	 */
	public WebElement  holidayFactor;
	@FindBy(how = How.XPATH, using = "//legend[text()='Search and Filter']")public WebElement legend_SearchAndFilter;
	@FindBy(how = How.XPATH, using = "//label[text()='Forecast Name:']")	public WebElement label_ForecastName;
	@FindBy(how = How.XPATH, using = "//label[text()='Created by User:']")	public WebElement label_CreateByUser;
	@FindBy(id = "idSearchForecastByNameAndUser")	                        public WebElement searchBtn;
	@FindBy(id = "searchForecastName")	                                    public WebElement inputField_ForecastName;
	@FindBy(id = "searchCreatedUser")				                        public WebElement dropDownField_CreatedByUser;
	@FindBy(how = How.XPATH, using = "//legend[text()='Holiday Factor']")   public WebElement txt_headingHolidayFactor;
	
	
	public void navigateToScreen() {
		clickOn(holidayFactor, "Holiday Screen");
	}
	
	/**
	 * Verify heading Holiday Factor at Holiday Factor screen 
	 */
	public void verifyHeadingHolidayFactor() {
		ExecutionLog.log("Verifying heading Holiday Factor.");
		ensureVisibilityOf(txt_headingHolidayFactor, "heading Holiday Factor");
	}
	
}
