package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

import static com.care.screens.CommonScreen.waitForSpinnerToDisappear;
import static com.care.utility.CommonMethods.*;

public class NewHiringOverrideScreen extends TestBase {

	// Initialize all the WebElements of New Hiring Override Screen
	public NewHiringOverrideScreen() {
			ExecutionLog.log("==========| New Hiring Override Screen |==========");
			curentPageID = "newHireOverrideFrom";
			PageFactory.initElements(driver, this);
	}
	
	/**
	 * @year=2019,2020
	 * @row=1 or 2 etc.
	 */
	String loc_rowNumber 		   = "//tr[@class='allHide tr_@year'][@row]";

	/**
	 * @year=2019,2020
	 * @row,@col=1 or 2 etc.
	 * @Day=Mon,Tue,Wed,Thu,Sat,Sun
	 */
	String loc_DaysOfWeekLabel 		   = "//tr[@class='allHide tr_@year'][@row]/td[@col][text()='@Day']";
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the New Hiring Override Screen 
	 */
	public WebElement  newHireOverride;
	@FindBy(how = How.XPATH, using = "//legend[contains(text(),'New Hire Override')]") public WebElement NewHireOverride_Legend;
	@FindBy(how = How.XPATH, using = "//a[text()='Clone ']")										public WebElement Clone_Btn;
	
	@FindBy(how = How.XPATH, using = "//th[text()='Days of Week']")										public WebElement NewHire_Header;
	
	
	public void navigateToScreen() {
		clickOn(newHireOverride, "New Hiring Override Screen");
		waitForSpinnerToDisappear();
		}
	}
