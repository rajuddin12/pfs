package com.care.screens;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;
/**
 * This class contains all possible UI elements (and its actions) of Allocation Objective Screen
 *
 */
public class AllocationObjectiveScreen extends TestBase {

	@FindBy(how = How.XPATH, using = "//span[@class='ddmenuicon collapsed']") 					public WebElement CapacityPlanningCollapsed;
																								public WebElement allocationObjective;
	@FindBy(how = How.XPATH, using = "//label[text()='Company:']") 								public WebElement CompanyLabel;
	@FindBy(how = How.XPATH, using = "//label[text()='Contact Center Site:']") 					public WebElement ContactCenterLabel;
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Erlang Efficiency Factor: ')]") 		public WebElement ErlangEfficiencyFactor_Label;
	@FindBy(how = How.ID, using = "erlangEfficiencyFactor") 									public WebElement ErlangEfficiencyFactor_input;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'div_Company')]/p/input[@type='checkbox']") 									public List<WebElement> companyCheckBoxes;
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'div_Contact')]/p[contains(@class,'displayContact')]/input[@type='checkbox']") 	public List<WebElement> contactCheckBoxes;
	
	
	

	
	public AllocationObjectiveScreen() {
		ExecutionLog.log("==========| Allocation Objective Screen |==========");	
		curentPageID = "allocationObjectiveForm";
		PageFactory.initElements(driver, this);
	}

	
	
	
	
}
