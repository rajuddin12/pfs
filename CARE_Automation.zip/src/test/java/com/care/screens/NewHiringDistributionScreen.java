package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

import static com.care.screens.CommonScreen.waitForSpinnerToDisappear;
import static com.care.utility.CommonMethods.*;

public class NewHiringDistributionScreen extends TestBase {

	// Initialize all the WebElements of New Hiring Distribution Screen
	public NewHiringDistributionScreen() {
			ExecutionLog.log("==========| New Hiring Distribution Screen |==========");
			curentPageID = "newHireDistributionForm";
			PageFactory.initElements(driver, this);
	}
	
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the New Hiring Distribution Screen 
	 */
	public WebElement  newHiringDistribution;
	@FindBy(how = How.XPATH, using = "//legend[contains(text(),'New Hire Schedule Distribution')]") public WebElement NewHireDistribution_Legend;
	@FindBy(how = How.XPATH, using = "//label[text()='New Employee Training Turnover %:']")			public WebElement EmployeeTrainingTurnover;
	@FindBy(how = How.XPATH, using = "//select[@id='forecastYear']")								public WebElement forecastYear_Header;
	@FindBy(how = How.XPATH, using = "//a[text()='Clone ']")										public WebElement Clone_Btn;
	@FindBy(how = How.XPATH, using = "//th[text()='New Hire']")										public WebElement NewHire_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='No. of New Hires']")								public WebElement NumberNewHire_Header;
	
	@FindBy(how = How.XPATH, using = "//th[text()='Weekly Schedule']")								public WebElement WeeklySchedule_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='Training']")										public WebElement Training_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='Nesting']")										public WebElement Nesting_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='Productivity % of Tenured Emp']")				public WebElement ProductivityOfTenuredEmp_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='Efficiency % of Tenured']")						public WebElement EfficiencyOfTenured_Header;

	
	public void navigateToScreen() {
		clickOn(newHiringDistribution, "New Hiring Distribution Screen");
		waitForSpinnerToDisappear();
		}
	}
