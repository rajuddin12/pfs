package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

import static com.care.screens.CommonScreen.waitForSpinnerToDisappear;
import static com.care.utility.CommonMethods.*;

public class DailyScheduledEmployeesScreen extends TestBase {

	// Initialize all the WebElements of Daily Scheduled Employees Screen
	public DailyScheduledEmployeesScreen() {
			ExecutionLog.log("==========| Daily Scheduled Employees Screen |==========");
			curentPageID = "dailyScheduledEmployee";
			PageFactory.initElements(driver, this);
	}
	
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the Daily Scheduled Employees Screen 
	 */
	public WebElement  dailyScheduledEmployees;
	@FindBy(how = How.XPATH, using = "//th[text()='Time Period']")						public WebElement TimePeriod_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='Allocation by Scheduled Employees']")public WebElement AllocationByScheduledEmployees_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='Year']")								public WebElement Year_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='Year']/following-sibling::th")		public WebElement Year_AdjacentHeader;

	@FindBy(how = How.XPATH, using = "//select[@id='top_panel_fiscalyear_select']")		public WebElement yearDropDown;
	@FindBy(how = How.XPATH, using = "//select[@id='top_panel_fiscalyear_select']/../following-sibling::th")		public WebElement scheduled;

	@FindBy(how = How.XPATH, using = "//label[text()='Enter First Week Schedule for Call Centers to proceed.']")public WebElement ErrorMessage;
	
	public void navigateToScreen() {
		clickOn(dailyScheduledEmployees, "Daily Scheduled Employees Screen");
		waitForSpinnerToDisappear();
	}
	

	
}
