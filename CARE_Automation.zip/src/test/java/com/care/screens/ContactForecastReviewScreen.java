package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;
/**
 * This class contains all possible UI elements (and its actions) of ContactForecastReview  screen
 *
 */
public class ContactForecastReviewScreen extends TestBase {

	public WebElement review;
	

	
	public ContactForecastReviewScreen() {
		ExecutionLog.log("==========| Contact Forecast Review Screen |==========");	
		curentPageID = "reviewForm";
		PageFactory.initElements(driver, this);
	}

	
	
	
}
