package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import static com.care.utility.CommonMethods.*;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

public class PredictiveVariablesScreen extends TestBase {

	public PredictiveVariablesScreen() {
			ExecutionLog.log("==========| Predictive Variables Screen |==========");
			curentPageID = "predVarFrom";
			PageFactory.initElements(driver, this);
	}
	
	/**
	 *@author J
	 *Defining all the WebElements on the Predictive Variables Screen 
	 */
	
	@FindBy(how = How.XPATH, using = "//fieldset[@class='scheduler-border']/legend")
	WebElement txt_headingPredictiveVar;
	@FindBy(how = How.XPATH, using = "(//fieldset[@class='scheduler-border']//h4)[1]")
	WebElement txt_headingSubscribersColumn;
	@FindBy(how = How.XPATH, using = "(//fieldset[@class='scheduler-border']//h4)[2]")
	WebElement txt_headingConnectsColumn;	
	@FindBy(how = How.XPATH, using = "(//fieldset[@class='scheduler-border']//h4)[3]")
	WebElement txt_headingDisconnectsColumn;
	@FindBy(how = How.ID, using = "notes")
	WebElement inp_notes;
	@FindBy(how = How.XPATH, using = "//fieldset[@class='scheduler-border']//a[text()='Next ']")
	WebElement btn_next;
	
	/**
	 * Verify user lands on Predictive Variable Screen
	 */
	public void verifyUserIsOnPredictiveVariablesScreen() {
		ExecutionLog.log("Verifying user is on predictive variable screen.");
		ensureVisibilityOf(txt_headingPredictiveVar, "Predictive Variables Heading.");
		ensureVisibilityOf(txt_headingSubscribersColumn, "Subscribers Column Heading.");
		ensureVisibilityOf(txt_headingConnectsColumn, "Connects Column Heading.");
		ensureVisibilityOf(txt_headingDisconnectsColumn, "Disconnects Column Heading.");
		
	}
	
	/**
	 * Select provided label under Subscribers section 
	 * @param label
	 */
	public void selectSubscribersLabel(String label) {
		ExecutionLog.log("Selecting lable: " + label + " from subscribers column.");
		WebElement checkBox = getElement("(//span[@id='subscribers']//label[text()='"+label+"']/preceding-sibling :: input)[last()]"); 
		clickOn(checkBox, "label-subscribers: " + label);
		verifyCheckboxIsChecked(checkBox, label, true);
	}
	
	/**
	 * Verify provided label under Subscribers section is selected 
	 * @param label
	 */
	public void verifySubscribersLabelIsSelected(String label) {
		ExecutionLog.log("Verifying lable: " + label + " from subscribers column is selected.");
		WebElement checkBox = getElement("(//span[@id='subscribers']//label[text()='"+label+"']/preceding-sibling :: input)[last()]"); 
		verifyCheckboxIsChecked(checkBox, label, true);
	}
	
	/**
	 * deSelect provided label under Subscribers section 
	 * @param label
	 */
	public void deSelectSubscribersLabel(String label) {
		ExecutionLog.log("Deselecting lable: " + label + " from subscribers column.");
		WebElement checkBox = getElement("(//span[@id='subscribers']//label[text()='"+label+"']/preceding-sibling :: input)[last()]"); 
		clickOn(checkBox, "label-subscribers: " + label);
		verifyCheckboxIsChecked(checkBox, label + " of Subscribers", false);
	}
	
	/**
	 * Select provided label under Connects section 
	 * @param label
	 */
	public void selectConnectsLabel(String label) {
		ExecutionLog.log("Selecting lable: " + label + " from Connects column.");
		WebElement checkBox = getElement("(//span[@id='connects']//label[text()='"+label+"']/preceding-sibling :: input)[last()]"); 
		clickOn(checkBox, "label-connects: " + label);
		verifyCheckboxIsChecked(checkBox, label + " of Connects", true);
	}
	
	/**
	 * Verify provided label under Connects section is selected 
	 * @param label
	 */
	public void verifyConnectsLabelIsSelected(String label) {
		ExecutionLog.log("Verifying lable: " + label + " from Connects column is selected.");
		WebElement checkBox = getElement("(//span[@id='connects']//label[text()='"+label+"']/preceding-sibling :: input)[last()]"); 
		verifyCheckboxIsChecked(checkBox, label + " of Connects", true);
	}
	
	
	/**
	 * Select provided label under Disconnects section 
	 * @param label
	 */
	public void selectDisconnectsLabel(String label) {
		ExecutionLog.log("Selecting lable: " + label + " from Disconnects column.");
		WebElement checkBox = getElement("(//span[@id='disconnects']//label[text()='"+label+"']/preceding-sibling :: input)[last()]");
		clickOn(checkBox, "label-disconnects: " + label);
		verifyCheckboxIsChecked(checkBox, label + " of Disconnects", true);
	}
	
	/**
	 * Verify provided label under Disconnects section is selected 
	 * @param label
	 */
	public void verifyDisconnectsLabelIsSelected(String label) {
		ExecutionLog.log("Verifying lable: " + label + " from Disconnects column is selected.");
		WebElement checkBox = getElement("(//span[@id='disconnects']//label[text()='"+label+"']/preceding-sibling :: input)[last()]");
		verifyCheckboxIsChecked(checkBox, label + " of Disconnects", true);
	}
}
