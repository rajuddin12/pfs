package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

import static com.care.screens.CommonScreen.waitForSpinnerToDisappear;
import static com.care.utility.CommonMethods.*;

public class OPAScreen extends TestBase {

	// Initialize all the WebElements of OPA Screen
	public OPAScreen() {
			ExecutionLog.log("==========| OPA Screen |==========");
			curentPageID = "unproductiveFrom";
			PageFactory.initElements(driver, this);
	}
	
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the OPA Screen 
	 */
	public WebElement  unproductiveTime;
	@FindBy(how = How.XPATH, using = "//legend[text()='OPA']")public WebElement OPA_Legend;
	@FindBy(how = How.XPATH, using = "//th[text()='OPA%']")public WebElement OPA_Perc_Header;
	@FindBy(how = How.XPATH, using = "//a[text()='Clone ']")public WebElement Clone_Btn;

	
	public void navigateToScreen() {
		clickOn(unproductiveTime, "OPA Screen");
		waitForSpinnerToDisappear();
	}
	

	
}
