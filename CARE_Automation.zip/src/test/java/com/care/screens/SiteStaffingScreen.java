package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

import static com.care.screens.CommonScreen.waitForSpinnerToDisappear;
import static com.care.utility.CommonMethods.*;

public class SiteStaffingScreen extends TestBase {

	// Initialize all the WebElements of Site Staffing Screen
	public SiteStaffingScreen() {
			ExecutionLog.log("==========| Site Staffing Screen |==========");
			curentPageID = "siteStaffingForm";
			PageFactory.initElements(driver, this);
	}
	
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the SiteStaffingScreen 
	 */
	public WebElement  siteStaffing;
	@FindBy(how = How.XPATH, using = "//legend[text()='First Week Schedule(FTE)']")public WebElement FTE_Legend;
	@FindBy(how = How.XPATH, using = "//th[text()='DOW']")public WebElement DOW_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='DOW']/following-sibling::th")public WebElement DOW_AdjacentHeader;

	@FindBy(how = How.XPATH, using = "//legend[text()='Turnover']")public WebElement Turnover_Legend;
	@FindBy(how = How.XPATH, using = "//label[text()='Enter First Week Schedule for Call Centers to proceed.']")public WebElement ErrorMessage;
	
	public void navigateToScreen() {
		clickOn(siteStaffing, "Site Staffing Screen");
		waitForSpinnerToDisappear();
	}
	

	
}
