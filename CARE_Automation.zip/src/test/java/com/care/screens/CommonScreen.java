package com.care.screens;

import static com.care.utility.CommonMethods.*;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

public class CommonScreen extends TestBase {

	public CommonScreen() {
		PageFactory.initElements(driver, this);
	}

	/**
	 *@author Jitendra 
	 *
	 */

	/**
	 * Verify following provided active breadcum navigation at top-left of the screen 
	 * @param activeBreadcumNav
	 */
	public static void verifyActiveBreadcumNavigation(String activeBreadcumNav) {
		ExecutionLog.log("Verifying active breadcum navigation '"+ activeBreadcumNav +"' at top-left of the screen.");
		verifyTextOf(getElement("//li[@class='breadcrumb-item active']"), activeBreadcumNav, "Breadcum Navigation");		

	}

	/**
	 * Verify following provided forecast name is present at top-left of the screen
	 * @param forcastName
	 */
	public static void verifyForcastName(String forcastName) {
		ExecutionLog.log("Verifying Forcast name: "+ forcastName +" is present at top-left of the screen.");
		verifyTextOf(getElement("//form[@id='" + curentPageID + "']//div[contains(@class, 'container')]/div/h4"), forcastName, "Forcast Name");

	}

	/**
	 * Verify following provided call type is present at top-right of the screen
	 * @param callType
	 */
	public static void verifySelectedValueOfCallType(String callTypeValue) {
		ExecutionLog.log("Verifying call type: "+ callTypeValue +" is selected.");
		verifyTextOf(getSelectedTextFromDropDown(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Call Type:']/../following-sibling :: p//select")), callTypeValue, "Call Type Drop Down");

	}
	
	/**
	 * Verify following provided Scheme is present at top-right of the screen
	 * @param Scheme
	 */
	public static void verifySelectedValueOfScheme(String scheme) {
		ExecutionLog.log("Verifying call type: "+ scheme +" is selected.");
		verifyTextOf(getSelectedTextFromDropDown(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Scheme:']/../following-sibling :: p//select")), scheme, "Scheme Drop Down");

	}


	/**
	 * Verify following provided fields are present at top of the screen 
	 * @param type
	 * @param period
	 * @param divisionName
	 * @param regionName
	 * @param lineOfWork
	 */
	public static void verifyForcastInfoAtScreenHeader(String type, String period, String divisionName, String regionName, String lineOfWork) {
		ExecutionLog.log("Verifying All the Headers present are in read-only mode as they are under 'p' tag (read only tag).");
		ExecutionLog.log("Verifying Forcast Type: "+ type +" is present at screen.");
		verifyTextOf(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Forecast Type:']/../following-sibling :: p"), type, "Forcast Type");
		ExecutionLog.log("Verifying Forcast Period: "+ period +" is present at screen.");
		verifyTextOf(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Forecast Period:']/../following-sibling :: p"), period, "Forcast Period");
		ExecutionLog.log("Verifying Division Name: "+ divisionName +" is present at screen.");
		verifyTextOf(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Division Name:']/../following-sibling :: p"), divisionName, "Division Name");
		ExecutionLog.log("Verifying Region Name: "+ regionName +" is present at screen.");
		verifyTextOf(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Region Name:']/../following-sibling :: p"), regionName, "Forcast Region");
		ExecutionLog.log("Verifying Line Of Work: "+ lineOfWork +" is present at screen.");
		verifyTextOf(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Line of Work:']/../following-sibling :: p"), lineOfWork, "Line Of Work");
		ExecutionLog.log("Verified that all the Headers present are in read-only mode as they under 'p' tag (read only tag).");

	}
	
	/**
	 * Click on Link Text as provided
	 * @param linkText
	 */
	public static void clickOnLink(String linkText) {
		clickOn(getElement("//a[text()='" + linkText + "']"), linkText);

	}

	/**
	 * Wait for spinner to disappear when switch to another screen
	 */
	public static void waitForSpinnerToDisappear() {
		ExecutionLog.log("Waiting for spinner to disappear.");
		waitForInVisibilityOf(getElements("//*[@data-icon='spinner'] | //*[contains(@class,'spinner')]"), 180, "Screen switch spinner");
	}

	/**
	 * Select the callType from drop-down as provided 
	 * @param callType
	 */
	public static void selectCallType(String callType) {
		selectValueFromDropDown(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Call Type:']/../following-sibling :: p//select"), callType, "Call Type Value");

	}
	
	/**
	 * Select the Scheme from drop-down as provided 
	 * @param Scheme
	 */
	public static void selectScheme(String scheme) {
		selectValueFromDropDown(getElement("//form[@id='" + curentPageID + "']//p/strong[text()='Scheme:']/../following-sibling :: p//select"), scheme, "Scheme");

	}

	public static void confirmPopUp() throws Exception {
		int i =0;
		while(getElement("changeConfirmationBtn").isDisplayed()) {
			clickOn(getElement("changeConfirmationBtn"), "confirm Button on Warning pop up") ;
			sleepTime(5);
			i++;
			if(i>5) break;
		}
	}

	public static void testNotesOfScreen(TestBase screenObj) throws Exception {
		// verify notes field
		// verify value of the note field
		// click the note field and verify the value i.e. Note is no more present
		// Enter data(min 20 Chars) in notes and verify
		//click next >> come back and verify the toop tip
		// Enter new note >> Next >> nav back and verify both tool tip msgs
		ExecutionLog.log("=====Enter First Note >> Next >> Navigate back to screen >> Verify the Tool Tip Message of Note=====");
		WebElement note = getElement("notes");
		String nextbtn= "//a[text()='Next '] | //*[@id='next']";
		String msg1 = curentPageID +  " Note 1" + "1234567890";
		String msg2 = curentPageID +  " Note 2" + "1234567890";
		String tooltipLocator= "//*[@id='notes']/..//p[text()='" + adminUserName +":@msg']";
		ensureVisibilityOf(note, "Note Field");
		verifyValueOf(note, "placeholder", "Notes", "grayed value in Note Field");
		verifyValueOf(note, "value", "", "Note Field");
		clickOn(note, "note Field");
		verifyValueOf(note, "value", "", "Note Field is empty after clicking Note");
		enterDataIn(note, msg1, "Note Field");
		verifyValueOf(note, "value", msg1, "Data in Note Field");		
		clickOn(getElement(nextbtn), "Next Button");
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");

		screenObj.navigateToScreen();
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");		
		note = getElement("notes");
		Actions act = new Actions(driver);
		act.moveToElement(note).build().perform();		
		ensureVisibilityOf(getElement(tooltipLocator.replace("@msg", msg1)), "Note msg in tool-tip");

		//////////Note-2//////////////////////
		ExecutionLog.log("=====Enter Second Note >> Next >> Navigate back to screen >> Verify the Tool Tip Message of Note=====");
		enterDataIn(note, msg2, "Note Field");
		verifyValueOf(note, "value", msg2, "Data in Note Field");		
		clickOn(getElement(nextbtn), "Next Button");
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
		screenObj.navigateToScreen();
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
		note = getElement("notes");
		act = new Actions(driver);
		act.moveToElement(note).build().perform();
		ensureVisibilityOf(getElement(tooltipLocator.replace("@msg", msg2)), msg2 + " Note msg in tool-tip");
		ExecutionLog.log("Verify Tool Tip");	
	}

	public static void logOutApplication() {
		ExecutionLog.log("Logging out application.");
		clickOn(getElement("//a[contains(@href, 'logout')]"), "LogOut Icon");
		
	}
	
}
