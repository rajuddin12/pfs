package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;
import static com.care.utility.CommonMethods.*;
/**
 * This class contains all possible UI elements (and its actions) of MultiplierScreen screen
 * @author Rajuddin
 *
 */
public class MultiplierScreen extends TestBase {

	public WebElement multiplier;	
	@FindBy(how = How.XPATH, using = "//table[contains(@id,'multiplierTable_') and @style='display: table;']/thead/tr/th[last()]")	public WebElement PVHeader;
	@FindBy(how = How.XPATH, using = "//legend[text()='Multiplier']")   															public WebElement txt_headingMultiplier;
	//First Data Row
	@FindBy(how = How.XPATH, using = "//table[contains(@id,'multiplierTable_') and @style='display: table;']//td") 											  public WebElement firstMonthDataRow;
	@FindBy(how = How.XPATH, using = "//table[contains(@id,'multiplierTable_') and @style='display: table;']//td/input[contains(@name,'predictiveVarValue')]")public WebElement firstPVDataRow;
	@FindBy(how = How.XPATH, using = "//table[contains(@id,'multiplierTable_') and @style='display: table;']//td/input[contains(@name,'coefficientValue')]")  public WebElement firstCoeffDataRow;
	@FindBy(how = How.XPATH, using = "//table[contains(@id,'multiplierTable_') and @style='display: table;']//td/input[@class='text-center numericonly']") 	  public WebElement firstTrendFDataRow;
	@FindBy(how =How.ID , using = "negative-coefficient")	   																		public WebElement negativeCoefficient;
	
	
	public MultiplierScreen() {
			ExecutionLog.log("==========| Multiplier Screen |==========");
			curentPageID = "multiplierFrom";
			PageFactory.initElements(driver, this);
	}
	
	public void navigateToScreen() {
		clickOn(multiplier, "Multiplier screen");
	}
	
	public void verifyHeaderAtMultiplerTable(String HeaderName) {
		String loc1 = "//table[contains(@id,'multiplierTable_')]//th[text()='" + HeaderName +"']";
		String loc2		= "//table[contains(@id,'multiplierTable_')]//th[text()='" + HeaderName.toLowerCase() +"']";
		ensureVisibilityOf(getElement(loc1 +"|" +loc2), HeaderName + " at Multipler Screen Header");
	}
	/**
	 * Verify heading  Multiplier at  Multiplier screen 
	 */
	public void verifyHeadingMultiplier() {
		ExecutionLog.log("Verifying heading  Multiplier.");
		ensureVisibilityOf(txt_headingMultiplier, "heading  Multiplier");
	}
	
	
}
