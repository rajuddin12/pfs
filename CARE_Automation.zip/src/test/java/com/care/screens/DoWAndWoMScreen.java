package com.care.screens;

import static com.care.utility.CommonMethods.*;
import static com.care.screens.CommonScreen.*;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

/**
 * This class contains all possible UI elements (and its actions) of DoW&AndWoM screen
 * @author JSaxena
 *
 */
public class DoWAndWoMScreen extends TestBase {

	List<String> daysOptions; 
	List<String> weekOptions;
	
	public DoWAndWoMScreen() {
			ExecutionLog.log("==========| DoWAndWoM Screen |==========");
			curentPageID = "dowdomFrom";
			daysOptions = new ArrayList<String>();
			weekOptions = new ArrayList<String>();
			PageFactory.initElements(driver, this);
	}
	
	public WebElement dayOfWeek ; 
	@FindBy(how = How.XPATH, using = "//legend[text()='Day of Week / Week of Month']")	WebElement txt_DoWAndWoMHeading;
	@FindBy(how = How.XPATH, using = "//div[@id='dowTable']//th[text()='Day']")	WebElement txt_DayHeading;
	@FindBy(how = How.XPATH, using = "//div[@id='dowTable']//th[text()='Day']/../../following-sibling :: tbody/tr/td[1]")
	List<WebElement>  list_txt_daysvalues;
	@FindBy(how = How.XPATH, using = "//div[@id='WomTable']//th[text()='Week']/../../following-sibling :: tbody/tr/td[1]")
	List<WebElement>  list_txt_weekvalues;
	@FindBy(how = How.XPATH, using = "//div[@id='dowTable']//th[text()='Day of Week %']")	WebElement txt_DayOfWeekHeading;
	@FindBy(how = How.ID, using = "retryRate")	WebElement inp_RetryRate;
	@FindBy(how = How.XPATH, using = "//div[@id='WomTable']/div[contains(text(),'Retry Rate')]")	WebElement txt_RetryRateLabel;
	@FindBy(how = How.XPATH, using = "//div[@id='WomTable']//th[text()='Week']")	WebElement txt_WeekHeading;
	@FindBy(how = How.XPATH, using = "//div[@id='WomTable']//th[text()='Week of Month %']")	WebElement txt_WeekOfMonth;
	@FindBy(how = How.LINK_TEXT, using = "Next")	WebElement button_Next;
	@FindBy(how = How.LINK_TEXT, using = "Review Forecast")	WebElement button_ReviewForecast;
	@FindBy(how = How.ID, using = "notes")	WebElement inp_Notes;
	@FindBy(how = How.XPATH, using = "//table[@id='dayOfWeekTable']//label[@id='lbl_saturday']") WebElement txt_dowSatLabel;
	@FindBy(how = How.XPATH, using = "//td[@id='td_Saturday']/input") WebElement inp_Saturday;
	@FindBy(how = How.XPATH, using = "//td[text()='Total']/following-sibling :: td/label") WebElement txt_Total;	
	@FindBy(how = How.XPATH, using = "//*[contains(text(),'Retry Rate:')]/input[@id='retryRate']")	WebElement inp_retryRate;
	@FindBy(how = How.XPATH, using = "//p[@id='dowRetryRate']") WebElement txt_retryRateErrorMessage;
	
   
	public void navigateToScreen() {
		clickOn(dayOfWeek, "DoWAndWoM Screen");
	}
	
	/**
	 * Verify 'Day of Week / Week of Month' heading is displayed 
	 */
	public void verifyDoWAndWoMHeading() {
		ExecutionLog.log("Verifying Heading - Day of Week / Week of Month");
		ensureVisibilityOf(txt_DoWAndWoMHeading, "'Day of Week / Week of Month' heading");
		
	}
	
	
	/**
	 * Verify body categories 
	 */
	public void verifyBodyCategories() {
		ExecutionLog.log("Verifying body categories:");
		ensureVisibilityOf(txt_DayHeading, "Table: Day");
		ensureVisibilityOf(txt_DayOfWeekHeading, "Table: Day Of Week %");
		ensureVisibilityOf(inp_RetryRate, "Input: Retry Rate");
		ensureVisibilityOf(txt_RetryRateLabel, "Label: Retry Rate");
		ensureVisibilityOf(txt_WeekHeading, "Table: Week");
		ensureVisibilityOf(txt_WeekOfMonth, "Table: Week of Month %");
		ensureVisibilityOf(button_ReviewForecast, "Button: Review Forecast");
		ensureVisibilityOf(button_Next, "Button: Next");
		ensureVisibilityOf(inp_Notes, "Input: Notes");
	}
	
	/**
	 * Return value of day(as provided) under DOW table 
	 * @param day
	 * @return
	 */
	public String getDOWTableLabels(String day) {
		if(day.equalsIgnoreCase("Saturday"))
			return txt_dowSatLabel.getText();
		
		return txt_dowSatLabel.getText();
	}

	/**
	 * Verify order of Day's options 
	 * @param daysList
	 */
	public void  verifyOrderOfDaysOptions(List<String> expctedDaysValues) {
		List<String> actualDaysValues = new ArrayList<String>();
		for(WebElement e : list_txt_daysvalues) {
			actualDaysValues.add(e.getText());
		}		
		compareListWithItemsOrder(actualDaysValues, expctedDaysValues, "Day's options");
	}
	
	/**
	 * Verify of Day's options input 
	 * @param daysList
	 */
	public void  verifyDaysOptionInputAreEditable() {
		for(WebElement e : list_txt_daysvalues) {
			if(e.getText().equals("Saturday") || e.getText().equals("Total")) {
				verifyElementIsNotDisplayed(getElements("//td[@id='td_" + e.getText() + "']/input"), "Input field for " + e.getText());
				continue;
			}				
			String randomNumber = String.valueOf(getRandomNumber(1, 15)); 
		    daysOptions.add(randomNumber);
		    assertTrue(isElementEditable(getElement("//td[@id='td_" + e.getText() + "']/input"), randomNumber, "Input field for " + e.getText()), "Verified element - Input field for " + e.getText() + " is NOT editable." );

		}		
		
	}
	
	/**
	 * Verify order of Week's options 
	 * @param weekList
	 */
	public void  verifyOrderOfWeekOptions(List<String> expctedWeekValues) {
		List<String> actualWeekValues = new ArrayList<String>();
		for(WebElement e : list_txt_weekvalues) {
			actualWeekValues.add(e.getText());
		}		
		compareListWithItemsOrder(actualWeekValues, expctedWeekValues, "Week's options");
	}
	
	/**
	 * Verify of Week's options input 
	 * 
	 */
	public void  verifyWeekOptionInputAreEditable() {
		for(WebElement e : list_txt_weekvalues) {
			String randomNumber = String.valueOf(getRandomNumber(1, 15));
			weekOptions.add(randomNumber);
		    Assert.assertTrue(isElementEditable(getElement("//td[text()='" + e.getText() + "']/following-sibling :: td/input"), randomNumber, "Input field for " + e.getText()), "[ASSERTION FAILED] Input field for " + e.getText() + " is NOT editable." );
		    
		}		
		
	}
		
	/**
	 * Get sum of Sunday - Friday
	 * @return
	 */
	public float getSumOfDaysFieldValues() {
		float sumOfDaysValue = 0.0F;
		
		for(WebElement e : list_txt_daysvalues) {
			if(e.getText().equals("Saturday") || e.getText().equals("Total")) 
				continue;			
			sumOfDaysValue += Float.parseFloat(getValueOfElement(getElement("//td[@id='td_" + e.getText() + "']/input")));
		}
		return sumOfDaysValue;
	}
	
	/**
	 * Get value of Saturday field
	 * Formula: Saturday value = 100 - getSumOfDaysFieldValues();
	 */
	public float getValueOfSaturdayField() {
		return 100 - getSumOfDaysFieldValues();
		
	}
	
	/**
	 * Verify Saturday field value 
	 */
	public void verifySaturdayFieldValue() {
		ExecutionLog.log("Verifying Saturday field value is calculated correctlty [value = 100 - SumOfDaysFieldValues]");
		String actualValue = getValueOfElement(inp_Saturday).split("%")[0];
		DecimalFormat df=new DecimalFormat("0.0");		
		String expectedValue = df.format(getValueOfSaturdayField());
		verifyStringsAreMatching(actualValue, expectedValue);
	}
	
	/**
	 * Get total's field value
	 */
	public float getTotalFieldValue() {
		return getSumOfDaysFieldValues() + getValueOfSaturdayField();
		
	}
	
	public void verifyTotalFieldValue() {
		ExecutionLog.log("Verifying Total's field value is calculated correctly");
		String actualValue = txt_Total.getText().split("%")[0];
		String expectedValue = String.valueOf(getTotalFieldValue());
		if(expectedValue.split("\\.")[1].equals("0"))
			expectedValue = expectedValue.split("\\.")[0];			
		verifyStringsAreMatching(actualValue, expectedValue);
		
	}
	
	/**
	 * Click on Next button
	 */
	public void clickOnNextButton1() {
		ExecutionLog.log("Clicking on Next button on DayOfWeekAndWeekOfMonth screen.");
		clickOnLink("Next ");
	}
	
	/**
	 * Verify Provided Week Values Are Retained On Screen After Refresh
	 */
	public void verifyProvidedWeekValuesAreRetainedOnScreenAfterRefresh() {
		ExecutionLog.log("Verifying provided week values are retained.");
		List<String> actualWeekValues = new ArrayList<String>();
		for(WebElement e : list_txt_weekvalues)
		      actualWeekValues.add(getValueOfElement(getElement("//td[text()='" + e.getText() + "']/following-sibling :: td/input")));
		compareListWithItemsOrder(actualWeekValues, weekOptions, "Weeks Input values");
	}
	
	/**
	 * Verify Provided day Values Are Retained On Screen After Refresh
	 */
	public void verifyProvidedDayValuesAreRetainedOnScreenAfterRefresh() {
		ExecutionLog.log("Verifying provided day values are retained.");
		List<String> actualdayValues = new ArrayList<String>();
		for(WebElement e : list_txt_daysvalues) {
			if(e.getText().equals("Saturday") || e.getText().equals("Total")) 
				continue;
			actualdayValues.add(getValueOfElement(getElement("//td[text()='" + e.getText() + "']/following-sibling :: td/input")));
		      
		}
		for(String str : actualdayValues) System.out.println("Actual> "+str);
		for(String str1 : daysOptions) System.out.println("Expected> "+str1);
		compareListWithItemsOrder(actualdayValues, daysOptions, "Days Input values");
	}
	
	/**
	 * Verify Retry Rate Input is displayed with default value as provided 
	 * 	@param value
	 */
	public void verifyRetryRateInputIsDisplayedWithDefalutValue(String value) {
		ensureVisibilityOf(inp_retryRate, "Retry Rate Input");
		ExecutionLog.log("Verifying Retry Rate input default value is " + value);
		verifyStringsAreMatching(inp_RetryRate.getAttribute("value"), value);
		
	}
	
	/**
	 * provide input to Retry Rate input
	 * @param value
	 */
	public void sendKeysToRetryRateInput(String value) {
		enterDataIn(inp_RetryRate, value, "Retry Rate Input");
		pressEnter(inp_RetryRate);
		ExecutionLog.log("Verifying input value of Retry Rate: " + value);
		verifyStringsAreMatching(inp_RetryRate.getAttribute("value"), value);
		
	}
	
	/**
	 * Verify Retry Rate Input Null error message
	 * @param errorMessage
	 */
	public void verifyErrorMessageIsDisplayed(String errorMessage) {
		ExecutionLog.log("Verifying Error message is displayed for NULL value of Retry Rate input.");
		verifyStringsAreMatching(txt_retryRateErrorMessage.getText(), errorMessage);		
		
	}
	
	/**
	 * Verify Retry rate input is not accepting less than zero value 
	 * Eg. Entering negative value as '-99' and verify input's final value is '99', as negative sign is skipped
	 */
	public void verifyRetryRateInputValueCanNotBeLessThanZero() {
		ExecutionLog.log("Verifying Retry Rate value can not be less than zero.");
		enterDataIn(inp_RetryRate, "-99", "Retry Rate Input");
		verifyStringsAreMatching(inp_RetryRate.getAttribute("value"), "99");
				
	}
	
	/**
	 * Verify Retry rate input is not accepting more than 100 value 
	 */
	public void verifyRetryRateInputValueCanNotBeMoreThan100(String alertMessage) {
		ExecutionLog.log("Verifying Retry Rate value can not be more than 100.");
		enterDataIn(inp_RetryRate, "101", "Retry Rate Input");
		verifyStringsAreMatching(getAlertText(driver), alertMessage);
	    acceptAlert(driver);	
	}
		
}
