package com.care.screens;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import static com.care.utility.CommonMethods.*;

import java.util.List;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

public class DashboardScreen extends TestBase {

	// Initialize all the WebElements of DashboardScreen
	public DashboardScreen() {
			ExecutionLog.log("==========| Dashboard Screen |==========");
			PageFactory.initElements(driver, this);
	}
	
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the Dashboard Page 
	 */
																		    public WebElement dashboard;
	@FindBy(how = How.XPATH, using = "//legend[text()='Search and Filter']")public WebElement legend_SearchAndFilter;
	@FindBy(how = How.XPATH, using = "//label[text()='Forecast Name:']")	public WebElement label_ForecastName;
	@FindBy(how = How.XPATH, using = "//label[text()='Created by User:']")	public WebElement label_CreateByUser;
	@FindBy(id = "idSearchForecastByNameAndUser")	                        public WebElement searchBtn;
	@FindBy(id = "searchForecastName")	                                    public WebElement inputField_ForecastName;
	@FindBy(id = "searchCreatedUser")				                        public WebElement dropDownField_CreatedByUser;

	/////////////////////////////////////WebElements of Active Forecast WebTable/////////////////////////////
    
	@FindBy(how = How.XPATH, using = "//div[@class='search-filter-container']//div[text()='Active Forecast']") public WebElement heading_ActiveForecast;	 													
	@FindBy(how = How.XPATH, using = "//span[@id='forecast_name_asc']/..")	public WebElement ForecastNameHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='forecast_type_asc']/..")	public WebElement ForecastTypeHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='forecast_period_asc']/..")public WebElement ForecastPeriodHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='create_date_asc']/..")	public WebElement CreateDateHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='created_by_asc']/..")   	public WebElement CreatedByHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='update_date_asc']/..")	public WebElement UpdateDateHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//th[text()='Comment']")	            public WebElement CommentHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='lock_asc']/..")        	public WebElement LockHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//th[text()='Edit']")                 public WebElement EditHeader_ActiveForecast;
	@FindBy(how = How.XPATH, using = "//th[text()='Clone']")             	public WebElement CloneHeader_ActiveForecast;
/*	@CacheLookup
	@FindBy(how = How.XPATH, using = "//*[@data-icon='spinner']")           public WebElement spinner;*/
	
/////////////////////////////////////WebElements of Archive Forecast WebTable/////////////////////////////
	
	@FindBy(how = How.XPATH, using = "//div[contains(@class,'container')]//div[text()='Archive Forecast']")	 public WebElement heading_ArchiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='forecast_name_archived_asc']/..")	 public WebElement ForecastNameHeader_ArchiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='forecast_type_archived_asc']/..")	 public WebElement ForecastTypeHeader_ArchiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='forecast_period_archived_asc']/..")public WebElement ForecastPeriodHeader_ArchiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='create_date_archived_asc']/..")	 public WebElement CreateDateHeader_ArchiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='created_by_archived_asc']/..")   	 public WebElement CreatedByHeader_ArchiveForecast;
	@FindBy(how = How.XPATH, using = "//span[@id='archive_date_archived_asc']/..")	 public WebElement ArchiveDateHeader_ArchiveForecast;
	@FindBy(how = How.XPATH, using = "//tbody[@id='dashboard_archive_forecast_table']/..//th[text()='Comment']")
																					 public WebElement CommentHeader_ArchiveForecast;
	@FindBy(how = How.XPATH, using = "//tbody[@id='dashboard_archive_forecast_table']/..//th[text()='Clone']")             	
																					public WebElement CloneHeader_ArchiveForecast;
	  																				public WebElement noForecastFound;
	public WebElement getElementOfGivenText(String text) {
		return driver.findElement(By.xpath("//*[text()='" + text + "']"));
	}
	
	public static List<WebElement> getLoadingSpinner() {
		return driver.findElements(By.xpath("//*[@data-icon='spinner'] | //*[contains(@class,'spinner')]"));
	}
	
	
	public void searchForecast(String forecastName, String createdByUser) {
		waitForInVisibilityOf(getLoadingSpinner(), 90, "Loading Spinner");
		enterDataIn(inputField_ForecastName, forecastName, "Forecast Name");
		selectValueFromDropDown(dropDownField_CreatedByUser, createdByUser, "createdByUser Drop Down");
		clickOn(searchBtn, "Search Button");
		waitForInVisibilityOf(getLoadingSpinner(), 90, "Loading Spinner");
		WebElement element = driver.findElement(By.xpath("//tbody[@id='dashboard_hist_forecast_table']/tr/td//a" + "[text()='" + forecastName+"']"));
		ensureVisibilityOf(element, forecastName);
	}
	
	/**
	 * 
	 * @param forecastName
	 * @param createdByUser
	 * @description: Ensure that respective Forecast is visible on the Dashboard else use searchForecast(String forecastName, String createdByUser)  to make visible
	 */
	public void selectForecast(String forecastName) {
		WebElement element = driver.findElement(By.xpath("//tbody[@id='dashboard_hist_forecast_table']/tr/td//a" + "[text()='" + forecastName+"']"));
		clickOn(element, forecastName + " forecast");
		waitForInVisibilityOf(getLoadingSpinner(), 180, "Loading Spinner");
	}
	
	public void searchForecastCaseSensitivity(String forecastNameToEnter, String forecastNameToVerify) {
		waitForInVisibilityOf(getLoadingSpinner(), 90, "Loading Spinner");
		enterDataIn(inputField_ForecastName, forecastNameToEnter, "Forecast Name");
		clickOn(searchBtn, "Search Button");
		waitForInVisibilityOf(getLoadingSpinner(), 90, "Loading Spinner");
		WebElement element = driver.findElement(By.xpath("//tbody[@id='dashboard_hist_forecast_table']/tr/td//a" + "[text()='" + forecastNameToVerify+"']"));
		ensureVisibilityOf(element, forecastNameToVerify);
	}
	
	/**
	 * Verify user is on dash board page. Asserts followings:
	 *  'Forecast Name' label and text field in header
	 *  'Created by User' label and drop-down in header
	 *  Active and Archive Forecast headings
	 */
	public void  verifyUserIsOnDashboardPage() {
		ExecutionLog.log("Verifying user is on Dashboard page.");
		ensureVisibilityOf(label_ForecastName, "Label: Forecast Name");
		ensureVisibilityOf(inputField_ForecastName, "Input: Forecast Name");
		ensureVisibilityOf(dropDownField_CreatedByUser, "Label: Created By User");
		ensureVisibilityOf(label_CreateByUser, "Dropdown: Created By User");
		ensureVisibilityOf(heading_ActiveForecast, "Heading: Active Forecast");
		ensureVisibilityOf(heading_ArchiveForecast, "Heading: Archive Forecast");
		
		
	}
}
