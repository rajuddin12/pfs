package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;

import static com.care.screens.CommonScreen.waitForSpinnerToDisappear;
import static com.care.utility.CommonMethods.*;

public class AHT_WOMScreen extends TestBase {

	// Initialize all the WebElements of AHT_WOM Screen
	public AHT_WOMScreen() {
			ExecutionLog.log("==========| AHT_WOM Screen |==========");
			curentPageID = "ahtWomFrom";
			PageFactory.initElements(driver, this);
	}
	
	/**
	 * @year=2019,2020
	 * @row=1 or 2 etc.
	 */
	String loc_rowNumber 		   = "//tr[@class='allHide tr_@year'][@row]";

	/**
	 * @year=2019,2020
	 * @row,@col=1 or 2 etc.
	 * @Day=Mon,Tue,Wed,Thu,Sat,Sun
	 */
	String loc_DaysOfWeekLabel 		   = "//tr[@class='allHide tr_@year'][@row]/td[@col][text()='@Day']";
	/**
	 *@author rajuddin
	 *Defining all the WebElements on the New Hiring Override Screen 
	 */
	public WebElement  ahtWom;

	
	@FindBy(how = How.XPATH, using = "//legend[contains(text(),'AHT Week Of Month')]") public WebElement AHTWeekOfMonth_Legend;
	@FindBy(how = How.XPATH, using = "//th[text()='Week']")							   public WebElement Week_Header;
	@FindBy(how = How.XPATH, using = "//th[text()='AHT Week Of Month%']")			   public WebElement AHTWeekOfMonth_Header;
	//div[@id='sld_CABLECARD']/p[text()='Service Level Definition:']
	
	
	public void navigateToScreen() {
		clickOn(ahtWom, "AHT_WOM Screen");
		waitForSpinnerToDisappear();
		}
	}
