package com.care.screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.care.reporting.ExecutionLog;
import com.care.test.base.TestBase;
import static com.care.utility.CommonMethods.*;

/**
 * This class contains all possible UI elements (and its actions) of HistoricalPeriod screen
 * @author JSaxena
 *
 */
public class HistoricalPeriodScreen extends TestBase {

	public WebElement historicalPeriod;
	public WebElement notes; 
	
	@FindBy(how = How.XPATH, using = "//legend[text()='Regression by Historical Period']")
	WebElement txt_RegressionByHistoricalPeriod;
	@FindBy(how = How.NAME, using  = "historicalDataHeaderChkBox")
	WebElement btn_HDtableHeaderCheckbox;
	
	
	/**
	 * Click on time period check box to select all data on HD page  
	 */
	public void clickOnTimePeriodCheckBox() {
		clickOn(btn_HDtableHeaderCheckbox, "All Time Period Checkbox");
		
	}
	
	public HistoricalPeriodScreen() {
			ExecutionLog.log("==========| Historical Period Screen |==========");
			curentPageID = "histPeriodForm";
			PageFactory.initElements(driver, this);
	}
	
	public void navigateToScreen() {
		clickOn(historicalPeriod, "historicalPeriod Screen");
	}
	
	public void noteFunctionalities() {
		try {
			verifyValueOf(notes, "value", "Notes", "Note Field");
		} catch (Exception e) {
			System.out.println("Note Testing Failed");
		}
		
	}
	
	/**
	 * Verify user is on RegressionByHistoricalPeriod heading 
	 */
	public void verifyRegressionByHistoricalPeriodHeading() {
		ExecutionLog.log("Verifying Heading - RegressionByHistoricalPeriod");
		ensureVisibilityOf(txt_RegressionByHistoricalPeriod, "RegressionByHistoricalPeriod heading");
		
	}
	
	/**
	 * Select data row at Historical Period Screen as per following provided parameters
	 * @param year
	 * @param month
	 */
	public void selectDataRowAtHistoricalPeriodScreen(String year, String month) {
	/*	if(year.equals("2016")) {
			if(appURL.contains("qa")) {
				year = "2018";
			}
		}		
	*/	ExecutionLog.log("Selecting row of " + month + ",  "+ year);
		WebElement checkBox = getElement("//input[@data-fiscalmth='"+ month +"' and @data-fiscalyear='" + year + "']");  
		clickOn( checkBox , "Select");
		verifyCheckboxIsChecked(checkBox, "Row of " + month + ", " + year, true);
	}
	
	/**
	 * Verify data row at Historical Period Screen as per following provided parameters is selected
	 * @param year
	 * @param month
	 */
	public void verifyDataRowAtHistoricalPeriodScreenIsSelected(String year, String month) {
		ExecutionLog.log("Verifying row of " + month + ",  "+ year + " is selected.");
		WebElement checkBox = getElement("//input[@data-fiscalmth='"+ month +"' and @data-fiscalyear='" + year + "']");  
		verifyCheckboxIsChecked(checkBox, "Row of " + month + ", " + year, true);
	}
	
}
