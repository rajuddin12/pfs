package com.care.testengine;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.HasInputDevices;
import org.openqa.selenium.interactions.Keyboard;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.care.reporting.ExecutionLog;
import static com.care.screens.CommonScreen.*;
import com.care.screens.CreateForecastScreen;
import com.care.screens.LoginScreen;
import com.care.test.base.TestBase;

import static com.care.utility.CommonMethods.*;

import java.util.ArrayList;
import java.util.List;

public class CreateForecastScreenTest extends TestBase	{


	@Test(description="Admin should see Associate Group", groups="Regression", enabled = true)
	public void TC1_AdminShouldSeeAssociatedGroup() {
		//ExtentTestManager.startTest("TC1-Admin should see Associate Group");

		//try {
			driver = TestBase.setDriver(browser, appURL);
			LoginScreen login = new LoginScreen();
			login.getLogin(adminUserName, adminPass);
			
			ExecutionLog.log("****************************************");
			ExecutionLog.log("URL:	" + appURL);
			ExecutionLog.log("Logged-In with Admin user: " + adminUserName);
			ExecutionLog.log("****************************************");
			
			CreateForecastScreen createForecast = new CreateForecastScreen();
			clickOn(createForecast.create_forecast, "Create Forecast");
			waitForSpinnerToDisappear();
			ensureVisibilityOf(createForecast.associatedGroup_Label,  "associatedGroup Label");
			ensureVisibilityOf(createForecast.associatedGroup,  "associatedGroup Drop Down");

			List<String> expectedData = new ArrayList<String>();
			expectedData.add("grp_Central");
			expectedData.add("grp_National");
			expectedData.add("grp_Northeast");
			expectedData.add("grp_West");
			expectedData.add("grp_XfinityMobile");
			equalLists(getAllDropDownValues(createForecast.associatedGroup), expectedData, "Associated Group");
			verifyValueOf(createForecast.associatedGroup,"multiple", "true" , "Dropdown Type of Associated Group");
			
			selectValueFromDropDown(createForecast.associatedGroup, "grp_Central", "Associated Group");
			Keyboard keyboard = ((HasInputDevices) driver).getKeyboard();
			keyboard.pressKey(Keys.CONTROL);
			selectValueFromDropDown(createForecast.associatedGroup, "grp_National", "Associated Group");
			keyboard.releaseKey(Keys.TAB);
			
			verifyValueFromDropDown(createForecast.associatedGroup, "grp_Central", "Associated Group");
			verifyValueFromDropDown(createForecast.associatedGroup, "grp_National", "Associated Group");
			/*clickOn(createForecast.newForecastSubmit, "Next Button");
			waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
			ensureVisibilityOf(createForecast.CreateForecasteScreenTwoHeader, ForecastName+" at the Header of Screen-Two-Of-CreateForecast");*/
		/*} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		}  catch (AssertionError e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		} finally {
			ExtentTestManager.endTest();
			driver.quit();
		}*/
		Assert.assertTrue(TestBase.TestCaseStatus, "Some Validations of the test case is failed");
	}

	@Test(description="TC2_NonAdmin Should Not See Associated Group", groups="Regression", enabled = true)
	public void TC2_NonAdminShouldNotSeeAssociatedGroup() {
		//ExtentTestManager.startTest("TC2_NonAdmin Should Not See Associated Group");

		//try {
			driver = TestBase.setDriver(browser, appURL);
			LoginScreen login = new LoginScreen();
			login.getLogin(nonAdminUserName, nonAdminPass);
			
			ExecutionLog.log("****************************************");
			ExecutionLog.log("*URL:	" + appURL);
			ExecutionLog.log("*Logged-In with Non-Admin user: " + nonAdminUserName);
			ExecutionLog.log("****************************************");
			
			CreateForecastScreen createForecast = new CreateForecastScreen();
			ensureInVisibilityOf(createForecast.associatedGroup_Label,  "associatedGroup Label");
			ensureInVisibilityOf(createForecast.associatedGroup,  "associatedGroup Drop Down");
			
		/*} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		}  catch (AssertionError e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		} finally {
			ExtentTestManager.endTest();
			driver.quit();
		}*/
			
		Assert.assertTrue(TestBase.TestCaseStatus, "Some Validations of the test case is failed");
		
	}

	@Test(description = "======CreateForecastScreenTest======", priority = 100)
	public void TestClassStatus() {
		Assert.assertTrue(TestBase.TestClassStatus);
	}

}

