package com.care.testengine;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static com.care.screens.CommonScreen.*;
import static com.care.utility.CommonMethods.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.care.screens.CreateForecastScreen;
import com.care.screens.DashboardScreen;
import com.care.screens.DoWAndWoMScreen;
import com.care.screens.LoginScreen;
import com.care.screens.MultiplierScreen;
import com.care.screens.PredictiveVariablesScreen;
import com.care.screens.HistoricalPeriodScreen;
import com.care.screens.HolidayScreen;
import com.care.test.base.TestBase;

/**
 * This test class contains test cases related to DoW&WoM Screen
 * 
 * @author JSaxena
 *
 */
public class DoWAndWoMScreenTest extends TestBase {
	LoginScreen login;
	DashboardScreen dashboard;
	CreateForecastScreen createForcast;
	PredictiveVariablesScreen predictiveVariables;
	DoWAndWoMScreen doAndWo;
	HistoricalPeriodScreen historicalPeriod;
	HolidayScreen holiday;
	MultiplierScreen multiplier;
	String forecastType;
	String forecastPeriod;
	String divisionName;
	String regionName;
	String lineOfWork;
	String callType;
	String PV1;
	String PV2;
	String PV3;
	String PV4;
	String dataRowAtHP_year1;
	String dataRowAtHP_month1;
	String dataRowAtHP_month2;
	String errorMsg_retryRate1;
	String errorMsg_retryRate2;
	List<String> daysOptions;
	List<String> weekOptions;
	Map<String, String> selectedValues;

	public void initVars() {
		forecastType = "Base";
		divisionName = "CENTRAL";
		regionName = "CHICAGO";
		lineOfWork = "PHONE";
		callType = "CABLE CARD";
		daysOptions = Arrays.asList("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday",
				"Total");
		weekOptions = Arrays.asList("Week 1", "Week 2", "Week 3", "Week 4", "Week 5");
		selectedValues = new HashMap<String, String>();
		PV1 = "Basic Service Residential";
		PV2 = "Average Cdvres";
		PV3 = "HSD";
		PV4 = "Bulk Units";
		errorMsg_retryRate1 = "The value of retry rate cannot be null.";
		errorMsg_retryRate2 = "Value for Retry rate cannot be more than 100";
	}

	@BeforeClass
	public void startTestSession() {
		setDriver();
		initVars();

	}

	@Test(description = "[TC1, TC2.1] Check for DoWAndWoM Screen", priority = 1)
	public void TC1_TC2_1_CheckForDoWAndWoMScreen() {

		login = new LoginScreen();
		login.getLogin(adminUserName, adminPass);

		dashboard = new DashboardScreen();
		dashboard.verifyUserIsOnDashboardPage();

		createForcast = new CreateForecastScreen();
		createForcast.clickOnCreateForecastLink();
		verifyActiveBreadcumNavigation("New Forecast");
		createForcast.createForecast(forecast_CreatedBy_adminUserName, "Base");
		waitForSpinnerToDisappear();

		predictiveVariables = new PredictiveVariablesScreen();
		verifyActiveBreadcumNavigation("Predictive Variables");
		verifyForcastName(forecast_CreatedBy_adminUserName);
		predictiveVariables.verifyUserIsOnPredictiveVariablesScreen();
		predictiveVariables.deSelectSubscribersLabel("Total");
		predictiveVariables.selectConnectsLabel(PV1);
		selectedValues.put("CABLE CARD", PV1);

		selectCallType("CDV");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CDV");
		predictiveVariables.deSelectSubscribersLabel("Total");
		predictiveVariables.selectSubscribersLabel(PV2);
		selectedValues.put("CDV", PV2);

		selectCallType("HSD");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("HSD");
		predictiveVariables.deSelectSubscribersLabel("Total");
		predictiveVariables.selectDisconnectsLabel(PV3);
		selectedValues.put("HSD", PV3);

		selectCallType("VIDEO");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("VIDEO");
		predictiveVariables.deSelectSubscribersLabel("Total");
		predictiveVariables.selectConnectsLabel(PV4);
		selectedValues.put("VIDEO", PV4);

		clickOnLink("Next ");
		waitForSpinnerToDisappear();

		historicalPeriod = new HistoricalPeriodScreen();
		dataRowAtHP_year1 = String.valueOf((Integer.parseInt(CreateForecastScreen.startYear_value) - 2));
		dataRowAtHP_month1 = "Jan";//CreateForecastScreen.startMonth_value;
		dataRowAtHP_month2 = CreateForecastScreen.endMonth_value;

		verifyActiveBreadcumNavigation("Historical Period");
		verifyForcastName(forecast_CreatedBy_adminUserName);
		historicalPeriod.verifyRegressionByHistoricalPeriodHeading();
		historicalPeriod.clickOnTimePeriodCheckBox();
		historicalPeriod.clickOnTimePeriodCheckBox();
		historicalPeriod.selectDataRowAtHistoricalPeriodScreen(dataRowAtHP_year1, dataRowAtHP_month1);
		historicalPeriod.selectDataRowAtHistoricalPeriodScreen(dataRowAtHP_year1, dataRowAtHP_month2);
		selectCallType("CDV");
		waitForSpinnerToDisappear();
		historicalPeriod.clickOnTimePeriodCheckBox();
		historicalPeriod.clickOnTimePeriodCheckBox();
		historicalPeriod.selectDataRowAtHistoricalPeriodScreen(dataRowAtHP_year1, dataRowAtHP_month1);
		historicalPeriod.selectDataRowAtHistoricalPeriodScreen(dataRowAtHP_year1, dataRowAtHP_month2);
		selectCallType("HSD");
		waitForSpinnerToDisappear();
		historicalPeriod.clickOnTimePeriodCheckBox();
		historicalPeriod.clickOnTimePeriodCheckBox();
		historicalPeriod.selectDataRowAtHistoricalPeriodScreen(dataRowAtHP_year1, dataRowAtHP_month1);
		historicalPeriod.selectDataRowAtHistoricalPeriodScreen(dataRowAtHP_year1, dataRowAtHP_month2);
		selectCallType("VIDEO");
		waitForSpinnerToDisappear();
		historicalPeriod.clickOnTimePeriodCheckBox();
		historicalPeriod.clickOnTimePeriodCheckBox();
		historicalPeriod.selectDataRowAtHistoricalPeriodScreen(dataRowAtHP_year1, dataRowAtHP_month1);
		historicalPeriod.selectDataRowAtHistoricalPeriodScreen(dataRowAtHP_year1, dataRowAtHP_month2);
		
		clickOnLink("Next ");
		waitForSpinnerToDisappear();

		doAndWo = new DoWAndWoMScreen();
		verifyActiveBreadcumNavigation("Day of Week");
		verifyForcastName(forecast_CreatedBy_adminUserName);
		doAndWo.verifyDoWAndWoMHeading();

	}

	@Test(description = "[ReTesting] Verify selected information on Predictive Variables screen is retained if user navigates to other screen", priority = 3)
	public void TC_VerifySelectedInformationOnPredictiveVariablesScreen() {
		clickOnLink("Predictive Variables");
		waitForSpinnerToDisappear();
		predictiveVariables = new PredictiveVariablesScreen();

		selectCallType("HSD");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("HSD");
		predictiveVariables.verifyDisconnectsLabelIsSelected(selectedValues.get("HSD"));
		selectCallType("CABLE CARD");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CABLE CARD");
		predictiveVariables.verifyConnectsLabelIsSelected(selectedValues.get("CABLE CARD"));
		selectCallType("CDV");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CDV");
		predictiveVariables.verifySubscribersLabelIsSelected(selectedValues.get("CDV"));
		selectCallType("VIDEO");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("VIDEO");
		predictiveVariables.verifyConnectsLabelIsSelected(selectedValues.get("VIDEO"));

	}

	@Test(description = "[ReTesting] Verify selected information on Historical Period screen is retained if user navigates to other screen", priority = 6)
	public void TC_VerifySelectedInformationHistoricalPeriodScreen() {
		clickOnLink("Historical Period");
		waitForSpinnerToDisappear();
		historicalPeriod = new HistoricalPeriodScreen();

		selectCallType("CABLE CARD");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CABLE CARD");
		historicalPeriod.verifyDataRowAtHistoricalPeriodScreenIsSelected(dataRowAtHP_year1, dataRowAtHP_month1);
		historicalPeriod.verifyDataRowAtHistoricalPeriodScreenIsSelected(dataRowAtHP_year1, dataRowAtHP_month2);

		selectCallType("CDV");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CDV");
		historicalPeriod.verifyDataRowAtHistoricalPeriodScreenIsSelected(dataRowAtHP_year1, dataRowAtHP_month1);
		historicalPeriod.verifyDataRowAtHistoricalPeriodScreenIsSelected(dataRowAtHP_year1, dataRowAtHP_month2);

	}

	@Test(description = "[TC2.2, TC3, TC4.1] Verify Header and Body categories of DoWAndWoM Screen", priority = 9)
	public void TC2_2_TC3_TC4_1_CheckForDoWAndWoMScreenCategories() {
		clickOnLink("Day of Week");
		waitForSpinnerToDisappear();
		doAndWo = new DoWAndWoMScreen();
		forecastPeriod = getForecastPeriod(CreateForecastScreen.startMonth_value, CreateForecastScreen.startYear_value,
				CreateForecastScreen.endMonth_value, CreateForecastScreen.endYear_value);
		verifyForcastInfoAtScreenHeader("Base", forecastPeriod, divisionName, regionName, lineOfWork);
		verifySelectedValueOfCallType(callType);
		doAndWo.verifyBodyCategories();

	}

	@Test(description = "[TC4.2, TC5] Verify all the fields in Header should be read only except Call Type", priority = 12)
	public void TC4_2_TC5_VerifyAllFieldsOfHeaderAreReadOnlyExceptCallType() {
		String satOfDOWValue = doAndWo.getDOWTableLabels("Saturday");
		selectCallType("CDV");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CDV");
		verifyStringsAreNotMatching(doAndWo.getDOWTableLabels("Saturday"), satOfDOWValue);

	}

	@Test(description = "[TC6, TC7] Verify day week and month categories for all call types", priority = 15)
	public void TC6_TC7_VerifyDayWeekAndMonthCategoriesForAllCallTypes() {
		selectCallType("CABLE CARD");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CABLE CARD");
		doAndWo.verifyBodyCategories();

		selectCallType("CDV");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CDV");
		doAndWo.verifyBodyCategories();

		selectCallType("HSD");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("HSD");
		doAndWo.verifyBodyCategories();

		selectCallType("VIDEO");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("VIDEO");
		doAndWo.verifyBodyCategories();

	}

	@Test(description = "[TC8] Verify order of day's options in Day of Week table", priority = 18)
	public void TC8_VerifyOrderOfDaysOptionsInDayOfWeekTable() {
		doAndWo.verifyOrderOfDaysOptions(daysOptions);

	}

	@Test(description = "[TC9, TC10] Verify day's option input are editable in Day of Week table", priority = 21)
	public void TC9_TC10_VerifyDaysOptionsInputAreEditableInDayOfWeekTable() {
		doAndWo.verifyDaysOptionInputAreEditable();

	}

	@Test(description = "[TC11] Verify Saturday value is calculated correctly as per formula", priority = 24)
	public void TC11_VerifySaturdayValueIsCalculatedCorrectly() {
		doAndWo.verifySaturdayFieldValue();
	}

	@Test(description = "[TC12] Verify Total value is calculated correctly", priority = 27)
	public void TC12_VerifyTotalValueIsCalculatedCorrectly() {
		doAndWo.verifyTotalFieldValue();
	}

	@Test(description = "[TC13] Verify order of week's options in Week of Month table", priority = 30)
	public void TC13_VerifyOrderOfWeekOptionsInWeekOfMonthTable() {
		doAndWo.verifyOrderOfWeekOptions(weekOptions);

	}

	@Test(description = "[TC14, TC15] Verify week's option input are editable in Week of Month table", priority = 33)
	public void TC14_TC15_VerifyWeekOptionsInputAreEditableInWeekOfMonthTable() {
		doAndWo.verifyWeekOptionInputAreEditable();

	}

	@Test(description = "[TC19.1] Verify Retry Rate input name and default value", priority = 34)
	public void TC19_1_VerifyRetryRateInputNameAndDefaultValue() {
		doAndWo.verifyRetryRateInputIsDisplayedWithDefalutValue("90.0");

	}

	@Test(description = "[TC19.2] Retry Rate input value check", priority = 35)
	public void TC19_2_RetryRateInputValueCheck() {
		doAndWo.sendKeysToRetryRateInput("");
		doAndWo.verifyErrorMessageIsDisplayed(errorMsg_retryRate1);
		doAndWo.sendKeysToRetryRateInput("10.5");
		doAndWo.verifyRetryRateInputValueCanNotBeLessThanZero();
		doAndWo.verifyRetryRateInputValueCanNotBeMoreThan100(errorMsg_retryRate2);
		doAndWo.sendKeysToRetryRateInput("25.6");

	}

	@Test(description = "[TC19.3] Retry Rate is per Call Type ", priority = 36)
	public void TC19_3_RetryRateIsPerCallType() {
		selectCallType("CDV");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CDV");
		doAndWo.verifyRetryRateInputIsDisplayedWithDefalutValue("90.0");

		selectCallType("CABLE CARD");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("CABLE CARD");
		doAndWo.verifyRetryRateInputIsDisplayedWithDefalutValue("90.0");

		selectCallType("HSD");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("HSD");
		doAndWo.verifyRetryRateInputIsDisplayedWithDefalutValue("90.0");

	}

	@Test(description = "[TC16] Verify user navigates to Multiplier Screen after clicking Next button", priority = 37)
	public void TC16_VerifyClickingOnNextButtonUserNavigatesToMultiplierScreen() {
		clickOnLink("Next ");
		waitForSpinnerToDisappear();
		multiplier = new MultiplierScreen();
		verifyActiveBreadcumNavigation("Multiplier");
		verifyForcastName(forecast_CreatedBy_adminUserName);
		multiplier.verifyHeadingMultiplier();

	}

	@Test(description = "[ReTesting] Verify overridden information on DoWAndWoM screen is retained if user navigates to other screen", priority = 39)
	public void verifyDataRetainsOnDayOfWeekScreenAfterAfterPageRefresh() {
		clickOnLink("Day of Week");
		waitForSpinnerToDisappear();
		verifyActiveBreadcumNavigation("Day of Week");
		new DoWAndWoMScreen();
		selectCallType("VIDEO");
		waitForSpinnerToDisappear();
		verifySelectedValueOfCallType("VIDEO");
		doAndWo.verifyProvidedDayValuesAreRetainedOnScreenAfterRefresh();
		doAndWo.verifyProvidedWeekValuesAreRetainedOnScreenAfterRefresh();

	}

	@Test(description = "[TC17] Verify user navigates to Review Contact Forecast Review screen after clicking on View Forecast button", priority = 41)
	public void TC17_VerifyUserNavigatesToReviewContactForecastScreen() {
		clickOnLink("Review Forecast ");
		waitForSpinnerToDisappear();
		verifyActiveBreadcumNavigation("Contact Forecast Review");
		
	}

	@Test(description = "[TC18] Verify freedom notes on DOW screen", priority = 43)
	public void TC18_VerifyFreedomNotesOnDOWScreen() throws Exception {
		clickOnLink("Day of Week");
		waitForSpinnerToDisappear();
		testNotesOfScreen(new DoWAndWoMScreen());

	}

	@Test(description = "[TC20.1] Create Forecast of Response Type", priority = 44)
	public void TC20_1_CreateForeCastOfResponseType() {
		logOutApplication();

		login.getLogin(adminUserName, adminPass);

		dashboard.verifyUserIsOnDashboardPage();

		createForcast.clickOnCreateForecastLink();
		verifyActiveBreadcumNavigation("New Forecast");
		TestBase.initSession();
		createForcast.createForecast(forecast_CreatedBy_adminUserName, "Response");
		verifyActiveBreadcumNavigation("Forecast(Response)");
		createForcast.verifyResponseTypeForcastName(forecast_CreatedBy_adminUserName);
		createForcast.verifyForcastInfoAtScreenHeaderForResponseTypeForecast("Response", forecastPeriod, divisionName,
				regionName, lineOfWork);
		createForcast.verifyResponseHeader();
		createForcast.verifySchemeIsAdded();

	}

	@Test(description = "[TC20.2] Add New Scheme", priority = 45)
	public void TC20_2_AddNewScheme() {
		waitForSpinnerToDisappear();
		createForcast.clickOnAddNewLinkToCreateMoreScheme();
		waitForSpinnerToDisappear();
		createForcast.addScheme("Scheme2");
		createForcast.verifySchemeIsAdded();
		waitForSpinnerToDisappear();
		clickOnLink("Next ");

	}

	@Test(description = "[TC20.3] Verify user is on DayOfWeek Screen", priority = 46)
	public void TC20_3_VerifyUserIsOnDayOfScreen() {
		waitForSpinnerToDisappear();
		doAndWo = new DoWAndWoMScreen();
		verifyActiveBreadcumNavigation("Day of Week");
		verifyForcastName(forecast_CreatedBy_adminUserName);
		doAndWo.verifyDoWAndWoMHeading();
		verifyForcastInfoAtScreenHeader("Response", forecastPeriod, divisionName, regionName, lineOfWork);
		doAndWo.verifyBodyCategories();

	}

	@Test(description = "[TC20.4] Verify Retry Rate on DayOfWeek Screen for Response Type Forecast", priority = 47)
	public void TC20_4_VerifyRetryRateOnDayOfScreen() {
		doAndWo.verifyRetryRateInputIsDisplayedWithDefalutValue("90.0");
		doAndWo.sendKeysToRetryRateInput("");
		doAndWo.verifyErrorMessageIsDisplayed(errorMsg_retryRate1);
		doAndWo.sendKeysToRetryRateInput("10.5");
		doAndWo.verifyRetryRateInputValueCanNotBeLessThanZero();
		doAndWo.verifyRetryRateInputValueCanNotBeMoreThan100(errorMsg_retryRate2);
		doAndWo.sendKeysToRetryRateInput("25.6");

		selectScheme("Scheme2");
		waitForSpinnerToDisappear();
		verifySelectedValueOfScheme("Scheme2");
		doAndWo.verifyRetryRateInputIsDisplayedWithDefalutValue("90.0");

		clickOnLink("Next ");
		waitForSpinnerToDisappear();
		holiday = new HolidayScreen();
		verifyActiveBreadcumNavigation("Holiday Factor");
		verifyForcastName(forecast_CreatedBy_adminUserName);
		holiday.verifyHeadingHolidayFactor();

	}

	@Test(description = "======DoWAndWoMScreen======", priority = 100)
	public void TestClassStatus() {
		Assert.assertTrue(TestBase.TestClassStatus);
	}
}
