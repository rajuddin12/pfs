package com.care.testengine;

import static com.care.utility.CommonMethods.*;
import static com.care.screens.CommonScreen.*;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.InvalidElementStateException;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

import com.care.reporting.ExecutionLog;
import com.care.screens.CommonScreen;
import com.care.screens.CreateForecastScreen;
import com.care.screens.DashboardScreen;
import com.care.screens.DoWAndWoMScreen;
import com.care.screens.HistoricalPeriodScreen;
import com.care.screens.LoginScreen;
import com.care.screens.MultiplierScreen;
import com.care.screens.PredictiveVariablesScreen;
import com.care.test.base.TestBase;
import com.care.utility.DateTimeHelper;

public class MultiplierScreenTest extends TestBase{

	LoginScreen login;
	CreateForecastScreen createForecast;
	MultiplierScreen multiplier; 

	String 	forecast_CreatedBy_adminUserName = "AUT_MultiplierTest" + DateTimeHelper.getCurrentDateTime(); 

	@Test(priority=1, groups="Regression", enabled = true, description="[TC1 TC2 TC3 TC4 TC5 and TC16] Check for the Multiplier screen parts and Forecast Header And Neg. Coeff.")
	public void  TC1_To_TC5_TC16_VerifyMultiplierScreenHeader() throws Exception {

		setDriver();
		login = new LoginScreen();
		login.getLogin(adminUserName, adminPass);

		ExecutionLog.log("====================");
		ExecutionLog.log("URL:	" + appURL);
		ExecutionLog.log("Logged-In with Admin user: " + adminUserName);
		ExecutionLog.log("====================");

		createForecast = new CreateForecastScreen();

		createForecast.createForecast(forecast_CreatedBy_adminUserName, "Base");	
		// On PV Screen
		PredictiveVariablesScreen pv =new PredictiveVariablesScreen();
		// De-select Subscribers's Total and select Total of Connects and Disconnects
		pv.deSelectSubscribersLabel("Total");
		pv.selectConnectsLabel("Total");
		pv.selectDisconnectsLabel("Total");
		clickOnLink("Next ");
		waitForSpinnerToDisappear();

		// On HistoricalPeriod Screen
		HistoricalPeriodScreen hp = new HistoricalPeriodScreen();
		hp.clickOnTimePeriodCheckBox();
		sleepTime(5);
		hp.clickOnTimePeriodCheckBox();
		hp.selectDataRowAtHistoricalPeriodScreen("2016", "Jan");
		hp.selectDataRowAtHistoricalPeriodScreen("2016", "Feb");
		hp.selectDataRowAtHistoricalPeriodScreen("2016", "Mar");
		
		waitForSpinnerToDisappear();
		clickOnLink("Next ");
		waitForSpinnerToDisappear();

		//On DOW Screen
		new DoWAndWoMScreen();
		clickOnLink("Next ");
		waitForSpinnerToDisappear();

		multiplier = new MultiplierScreen();
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
		ensureVisibilityOf(multiplier.multiplier, "Multiplier Header");			

		CommonScreen.verifyActiveBreadcumNavigation("Multiplier");
		ExecutionLog.log("==========| END of TC1 |==========");

		ExecutionLog.log("");
		ExecutionLog.log("==========| TC2 and TC3 : Check for the Multiplier screen parts |==========");
		ExecutionLog.log("==========| AND |==========");
		ExecutionLog.log("==========| TC4 and TC5 : Check for the Multiplier screen header column field, Call Type field (editable or not) |==========");
		verifyForcastName(forecast_CreatedBy_adminUserName);
		verifyForcastInfoAtScreenHeader("Base", getMonthNumberFromString(CreateForecastScreen.startMonth_value) + "/" + CreateForecastScreen.startYear_value + " - " + getMonthNumberFromString(CreateForecastScreen.endMonth_value) + "/" + CreateForecastScreen.endYear_value, "CENTRAL", "CHICAGO", "PHONE");

		List<String> expectedData = new ArrayList<String>();
		expectedData.add("CABLE CARD");
		expectedData.add("CDV");
		expectedData.add("HSD");
		expectedData.add("VIDEO");
		equalLists(getAllDropDownValues(getElement("top_panel_call_type_select")), expectedData, "Call Type");
		if(getElement("top_panel_call_type_select").getAttribute("multiple")==null) {
			ExecutionLog.log("Call type is single drop down");
		} else ExecutionLog.log("[Failed]: Call type is NOT single drop down");

		ExecutionLog.log("==========| END of TC2, TC3, TC4 and TC5 |==========");
		ExecutionLog.log("");
		ExecutionLog.log("==========| TC16 Negative Coefficient Test |==========");
		verifyTextOf(multiplier.negativeCoefficient, "Warning: Negative coefficient exists for CABLE CARD", "Negative Coefficient msg at Multiplier Screen");

		ExecutionLog.log("==========| END of TC16 |==========");
		Assert.assertTrue(TestBase.TestCaseStatus, "Some Validations of the test case is failed");
	}

	@Test(priority=2, groups="Regression", enabled = true, description="[TC6 TC7 TC9 TC10] Check for Multiplier screen body columns")
	public void  TC6_TC7_TC9_TC10_Check_For_Multiplier_Screen_Body_Columns() {

		ExecutionLog.log("==========| Start Execution of TC6 TC7 TC9 and TC10: Check for Multiplier screen body columns |==========");
		verifyTextOf(multiplier.PVHeader, "CABLE CARD Predictive Variables",  "PV Header");

		multiplier.verifyHeaderAtMultiplerTable("Month");
		multiplier.verifyHeaderAtMultiplerTable("Connects: total");
		multiplier.verifyHeaderAtMultiplerTable("Coefficient");
		multiplier.verifyHeaderAtMultiplerTable("Disconnects: total");
		multiplier.verifyHeaderAtMultiplerTable("Trend Factor %");

		ExecutionLog.log("");
		ExecutionLog.log("****Change Call Type and Verify PV Header******");
		selectCallType("CDV");
		verifyTextOf(multiplier.PVHeader, "CDV Predictive Variables",  "CDV PV Header");
		selectCallType("HSD");
		verifyTextOf(multiplier.PVHeader, "HSD Predictive Variables",  "HSD PV Header");
		selectCallType("VIDEO");
		verifyTextOf(multiplier.PVHeader, "VIDEO Predictive Variables",  "VIDEO PV Header");
		ExecutionLog.log("==========| END Execution of TC6 TC7 TC9 and TC10 |==========");
		Assert.assertTrue(TestBase.TestCaseStatus, "Some Validations of the test case is failed");
	}

	@Test(priority=3, groups="Regression", enabled = true, description="[TC8 TC11-TC13 TC15 ] Check  editable status of Multiplier screen body column")
	public void  TC8_TC11_To_TC13_TC15_Check_For_FieldsEditableStatus() throws Exception {
		ExecutionLog.log("==========| TC8 : Check for Multiplier screen body column edit boxes |==========");
		//String nextbtn= "//a[text()='Next '] | //*[@id='next']";

		sleepTime(20);
		try {
			assertFalse(isElementEditable(multiplier.firstMonthDataRow, "abc", "firstMonthDataRow"), "firstMonthDataRow is NOT editable");
		} catch (InvalidElementStateException e) {
			ExecutionLog.log("Verified that Data row of first Month is Non-Editable");
			//invalid element state: Element must be user-editable in order to clear it.
		}

		ExecutionLog.log("==========Verifying user should be able to Override Default value==========");
		String defaultValueInPV 	= getAttribute(multiplier.firstPVDataRow, "value").replace(",", "");
		String defaultValueInCoeff 	= getAttribute(multiplier.firstCoeffDataRow, "value").replace(",", "");
		String defaultValueInTrend 	= getAttribute(multiplier.firstTrendFDataRow, "value");

		assertTrue(isElementEditable(multiplier.firstPVDataRow, 	"123", "firstPVDataRow"), "firstPVDataRow is NOT editable");	
		assertTrue(isElementEditable(multiplier.firstTrendFDataRow, "88", "first Trend Data Row"), "first TrendF DataRow is NOT editable");
		assertTrue(isElementEditable(multiplier.firstCoeffDataRow, 	"0", "firstCoeffDataRow"), "first Coeff DataRow is NOT editable");

		ExecutionLog.log("========| TC15: User should not progress past this screen if (pop a message related to why the user can't progress) |=======");
		keyboard_TAB();
		sleepTime(10);
		String warningMsg = "Warning: A Coefficient has been changed. Are you sure you want to continue?";
		verifyTextOf(getElement("//div[@id='warningModal']//div[@class='modal-body']"), warningMsg, "warningMsg while changing Coefficient");

		sleepTime(10);
		confirmPopUp();

		sleepTime(5);
		Actions act = new Actions(driver);
		act.doubleClick(getElement("changeConfirmationBtn")).build().perform();
		sleepTime(20);

		ExecutionLog.log("==========| TC11 and TC12 : Verify User can enter valid value in PV and PV Coeff field |==========");
		ExecutionLog.log("==========| Failed: Bug: Value Entered in PV fields are not getting saved |==========");
		/*
		//act.moveToElement(getElement(nextbtn)).build().perform();
		//act.doubleClick(getElement("//button[@type='submit']")).build().perform();
		clickOn(getElement(nextbtn), "Next Button");//opening two window
		sleepTime(20);
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
		multiplier.navigateToScreen();
		waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
		verifyValueOf(multiplier.firstPVDataRow, "value", "123", "firstPVDataRow");
		verifyValueOf(multiplier.firstCoeffDataRow, "value", "456", "firstCoeffDataRow");
		 */
		ExecutionLog.log("-----TearDown: Entering Default values-----");
		enterDataIn(multiplier.firstPVDataRow, 		defaultValueInPV, 		"PV Field");
		enterDataIn(multiplier.firstTrendFDataRow, 	defaultValueInTrend, 	"TrendF Field");
		enterDataIn(multiplier.firstCoeffDataRow, 	defaultValueInCoeff, 	"Coeff Field");

		sleepTime(10);
		confirmPopUp();

		ExecutionLog.log("");
		ExecutionLog.log("==========| TC13 : Check whether user can enter an invalid value |==========");
		ExecutionLog.log("==========Verifying that PV, Coefficient and Trend Factor Field does NOT accept Alphabets and special characters==========");
		assertFalse(isElementEditable(multiplier.firstPVDataRow, 	"abc$", "first PV Data Row"), "first PV DataRow is editable with alphanumeric charac");
		assertFalse(isElementEditable(multiplier.firstCoeffDataRow, "abc$", "first Coeff Data Row"), "first Coeff DataRow is editable with alphanumeric charac");
		sleepTime(20);
		confirmPopUp();
		assertFalse(isElementEditable(multiplier.firstTrendFDataRow, "abc$", "first Trend Data Row"), "first TrendF DataRow is editable with alphanumeric charac");
		Assert.assertTrue(TestBase.TestCaseStatus, "Some Validations of the test case is failed");
		
	}

	@Test(priority=5, groups="Regression", enabled = true, description="[TC17] Test the Functionality of Notes")
	public void  TC17_verifyNotes() throws Exception {	
		testNotesOfScreen(multiplier);	
		Assert.assertTrue(TestBase.TestCaseStatus, "Some Validations of the test case is failed");
	}

	@Test(priority=4, groups="Regression", enabled = true, description="[TC14] R-Square")
	public void  TC14_R_Square() throws Exception {	
		throw new SkipException("Waiting for the Formula for the calculation of R-Square");
//		Assert.assertTrue(TestBase.TestCaseStatus, "Some Validations of the test case is failed");
	}
	
	
	@Test(priority=20, description="======MultiplierScreen======")
	public void TestClassStatus() {
		Assert.assertTrue(TestBase.TestClassStatus);
		driver.quit();
	}

}
