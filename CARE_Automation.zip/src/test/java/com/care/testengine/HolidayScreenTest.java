package com.care.testengine;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.care.reporting.ExecutionLog;
import com.care.reporting.ExtentTestManager;
import com.care.reporting.ReportScreenshot;
import com.care.screens.CreateForecastScreen;
import com.care.screens.DashboardScreen;
import com.care.screens.LoginScreen;
import com.care.test.base.TestBase;
import com.care.utility.DateTimeHelper;
import com.relevantcodes.extentreports.LogStatus;

import static com.care.utility.CommonMethods.*;

public class HolidayScreenTest extends TestBase{

	String forecast_CreatedBy_adminUserName 	= "AUT_Forecast_adminUserName" + DateTimeHelper.getCurrentDateTime();
	String forecast_CreatedBy_NonadminUserName 	= "AUT_Forecast_NonadminUserName" + DateTimeHelper.getCurrentDateTime();

	@Test(description="Admin should see all forecasts", groups="Regression", enabled = true)
	public void TC1() {
		ExtentTestManager.startTest("TC1-TC5-Admin should see all forecasts");

		try {
			driver = TestBase.setDriver(browser, appURL);
			LoginScreen login = new LoginScreen();
			login.getLogin(adminUserName, adminPass);
			
			ExecutionLog.log("****************************************");
			ExecutionLog.log("URL:	" + appURL);
			ExecutionLog.log("Logged-In with Admin user: " + adminUserName);
			ExecutionLog.log("****************************************");
			
			
			DashboardScreen dash = new DashboardScreen();
			dash.searchForecast("Rajuddin2_05_Nov_2018", "");
			CreateForecastScreen createForecast = new CreateForecastScreen();
			createForecast.createForecast(forecast_CreatedBy_adminUserName, "Base");

			ExecutionLog.log("");
			ExecutionLog.log("******************Dashboard Screen******************");
			
			clickOn(dash.dashboard, "Dashboard Menu");
			waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
			ensureVisibilityOf(dash.legend_SearchAndFilter, "legend_SearchAndFilter");
			ensureVisibilityOf(dash.label_ForecastName, 	"label_ForecastName");
			ensureVisibilityOf(dash.label_ForecastName, 	"legend_SearchAndFilter");
			ensureVisibilityOf(dash.searchBtn, 				"search Button");
			ensureVisibilityOf(dash.dropDownField_CreatedByUser, 				"CreatedByUser Drop Down");
			ExecutionLog.log("Verifying Admin can see Non-Amin user");
			verifyValueFromDropDown(dash.dropDownField_CreatedByUser, nonAdminUserName, "CreatedByUser Drop Down");
			dash.searchForecast(forecast_CreatedBy_adminUserName, adminUserName);

			ExecutionLog.log("");
			ExecutionLog.log("Verify the Default value of forecast Field");
			verifyValueOf(dash.inputField_ForecastName, "placeholder", "Enter Name", "ForecastName");
			// Testing the case sensitivity functionality of forecast search
			dash.searchForecastCaseSensitivity(forecast_CreatedBy_adminUserName.replace("AUT", "aut"), forecast_CreatedBy_adminUserName);
			dash.searchForecastCaseSensitivity(forecast_CreatedBy_adminUserName.replace("Forecast", "FORECAST"), forecast_CreatedBy_adminUserName);

			// Verifying no Forecast Found message
			waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
			enterDataIn(dash.inputField_ForecastName, "NotFoundForecast_tytytyty", "Forecast Name");
			clickOn(dash.searchBtn, "Search Button");
			waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
			ensureVisibilityOf(dash.noForecastFound, "No forecast Found message");



			ExecutionLog.log("");
			ExecutionLog.log("Verify the available Headers of Active Forecast Table");
			// Verifying the Headers of Active Forecasts Window
			ensureVisibilityOf(dash.getElementOfGivenText("Active Forecast"), "Active Forecast");
			// Verifying pagination/Navigation items of the Active Forecast Windows
			verifyValueOf(dash.ForecastNameHeader_ActiveForecast,   "innerText", "Forecast Name", 	"ForecastName Header under 'Active Forecast' table");
			verifyValueOf(dash.ForecastTypeHeader_ActiveForecast,   "innerText", "Forecast Type", 	"Forecast Type Header under 'Active Forecast' table");
			verifyValueOf(dash.ForecastPeriodHeader_ActiveForecast, "innerText", "Forecast Period",	"Period Header under 'Active Forecast' table");
			verifyValueOf(dash.CreateDateHeader_ActiveForecast,     "innerText", "Create Date", "CreateDate Header under 'Active Forecast' table");
			verifyValueOf(dash.CreatedByHeader_ActiveForecast,      "innerText", "Created By", 	"CreatedBy Header under 'Active Forecast' table");
			verifyValueOf(dash.UpdateDateHeader_ActiveForecast,     "innerText", "Update Date", "UpdateDate Header under 'Active Forecast' table");
			verifyValueOf(dash.CommentHeader_ActiveForecast, 		"innerText", "Comment", 	"Comment Header under 'Active Forecast' table");
			verifyValueOf(dash.LockHeader_ActiveForecast, 			"innerText", "Lock", 		"Lock Header under 'Active Forecast' table");
			verifyValueOf(dash.EditHeader_ActiveForecast, 			"innerText", "Edit", 		"Edit Header under 'Active Forecast' table");
			verifyValueOf(dash.CloneHeader_ActiveForecast, 			"innerText", "Clone", 		"Clone Header under 'Active Forecast' table");



			// Verifying the Headers of Archive Forecasts Window
			ExecutionLog.log("");
			ExecutionLog.log("Verify the available Headers of Archive Forecast Table");
			// Verifying the Headers of Archive Forecasts Window
			ensureVisibilityOf(dash.getElementOfGivenText("Archive Forecast"), "Archive Forecast");
			// Verifying pagination/Navigation items of the Archive Forecast Windows
			verifyValueOf(dash.ForecastNameHeader_ArchiveForecast,   "innerText", "Forecast Name", 	"ForecastName Header under 'Archive Forecast' table");
			verifyValueOf(dash.ForecastTypeHeader_ArchiveForecast,   "innerText", "Forecast Type", 	"Forecast Type Header under 'Archive Forecast' table");
			verifyValueOf(dash.ForecastPeriodHeader_ArchiveForecast, "innerText", "Forecast Period",			"Period Header under 'Archive Forecast' table");
			verifyValueOf(dash.CreateDateHeader_ArchiveForecast,     "innerText", "Create Date","CreateDate Header under 'Archive Forecast' table");
			verifyValueOf(dash.CreatedByHeader_ArchiveForecast,      "innerText", "Created By", "CreatedBy Header under 'Archive Forecast' table");
			verifyValueOf(dash.ArchiveDateHeader_ArchiveForecast,     "innerText", "Archive Date","Archive Date Header under 'Archive Forecast' table");
			verifyValueOf(dash.CommentHeader_ArchiveForecast, 		 "innerText", "Comment", 		"Comment Header under 'Archive Forecast' table");
			verifyValueOf(dash.CloneHeader_ArchiveForecast, 		 "innerText", "Clone", 	"Clone Header under 'Archive Forecast' table");

			ExtentTestManager.endTest();
			driver.quit();

		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		}  catch (AssertionError e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		} finally {
			ExtentTestManager.endTest();
			driver.quit();
		}
	}

	@Test(description="Non-Admin should see forecasts for assigned group", groups="Regression", enabled= true)
	public void TC2_TC7_NonAdminShouldSeeForecastsOfAssignedGroup() {
		////////////////////////////////////////////////////////////////////////////////////
		//	Discussion of TC2
		// 	Anandhvidya to Rajuddin: will Discuss on the call
		// 	Rajuddin and Vidya Discussion on 12th Nov:
		//		Vidya will be discussing with Ahsaan and sushil
		//		*Verify only Created By UserOnly for Non-Admin user
		////////////////////////////////////////////////////////////////////////////////////

		try {
			driver = TestBase.setDriver(browser, appURL);
			LoginScreen login = new LoginScreen();
			login.getLogin(nonAdminUserName, nonAdminPass);
			
			ExecutionLog.log("****************************************");
			ExecutionLog.log("URL:	" + appURL);
			ExecutionLog.log("Logged-In with Non-Admin user: " + nonAdminUserName);
			ExecutionLog.log("****************************************");
			
			CreateForecastScreen createForecast = new CreateForecastScreen();
			createForecast.createForecast(forecast_CreatedBy_NonadminUserName, "Base");


			ExecutionLog.log("");
			ExecutionLog.log("******************Dashboard Screen******************");
			DashboardScreen dash = new DashboardScreen();
			clickOn(dash.dashboard, "Dashboard Menu");
			waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
			ensureVisibilityOf(dash.legend_SearchAndFilter, "legend_SearchAndFilter");
			ensureVisibilityOf(dash.label_ForecastName, 	"label_ForecastName");
			ensureVisibilityOf(dash.label_ForecastName, 	"legend_SearchAndFilter");
			ensureVisibilityOf(dash.searchBtn, 				"search Button");
			ensureVisibilityOf(dash.dropDownField_CreatedByUser, 				"CreatedByUser Drop Down");

			ExecutionLog.log("Verifying Non-Admin can not see Amin user");
			verifyValueNotPresentInDropDown(dash.dropDownField_CreatedByUser, adminUserName, "CreatedByUser Drop Down");
			
			ExecutionLog.log("");
			ExecutionLog.log("Verify the Default value of forecast Field");
			verifyValueOf(dash.inputField_ForecastName, "placeholder", "Enter Name", "ForecastName");
			// Testing the case sensitivity functionality of forecast search
			dash.searchForecastCaseSensitivity(forecast_CreatedBy_NonadminUserName.replace("AUT", "aut"), forecast_CreatedBy_NonadminUserName);
			dash.searchForecastCaseSensitivity(forecast_CreatedBy_NonadminUserName.replace("Forecast", "FORECAST"), forecast_CreatedBy_NonadminUserName);

			// Verifying no Forecast Found message
			waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
			enterDataIn(dash.inputField_ForecastName, "NotFoundForecast_tytytyty", "Forecast Name");
			clickOn(dash.searchBtn, "Search Button");
			waitForInVisibilityOf(DashboardScreen.getLoadingSpinner(), 90, "Loading Spinner");
			ensureVisibilityOf(dash.noForecastFound, "No forecast Found message");

			ExecutionLog.log("");
			ExecutionLog.log("Verify the available Headers of Active Forecast Table");
			// Verifying the Headers of Active Forecasts Window
			ensureVisibilityOf(dash.getElementOfGivenText("Active Forecast"), "Active Forecast");
			// Verifying pagination/Navigation items of the Active Forecast Windows
			verifyValueOf(dash.ForecastNameHeader_ActiveForecast,   "innerText", "Forecast Name", 	"ForecastName Header under 'Active Forecast' table");
			verifyValueOf(dash.ForecastTypeHeader_ActiveForecast,   "innerText", "Forecast Type", 	"Forecast Type Header under 'Active Forecast' table");
			verifyValueOf(dash.ForecastPeriodHeader_ActiveForecast, "innerText", "Forecast Period",	"Period Header under 'Active Forecast' table");
			verifyValueOf(dash.CreateDateHeader_ActiveForecast,     "innerText", "Create Date", "CreateDate Header under 'Active Forecast' table");
			verifyValueOf(dash.CreatedByHeader_ActiveForecast,      "innerText", "Created By", 	"CreatedBy Header under 'Active Forecast' table");
			verifyValueOf(dash.UpdateDateHeader_ActiveForecast,     "innerText", "Update Date", "UpdateDate Header under 'Active Forecast' table");
			verifyValueOf(dash.CommentHeader_ActiveForecast, 		"innerText", "Comment", 	"Comment Header under 'Active Forecast' table");
			verifyValueOf(dash.LockHeader_ActiveForecast, 			"innerText", "Lock", 		"Lock Header under 'Active Forecast' table");
			verifyValueOf(dash.EditHeader_ActiveForecast, 			"innerText", "Edit", 		"Edit Header under 'Active Forecast' table");
			verifyValueOf(dash.CloneHeader_ActiveForecast, 			"innerText", "Clone", 		"Clone Header under 'Active Forecast' table");

			// Verifying the Headers of Archive Forecasts Window
			ExecutionLog.log("");
			ExecutionLog.log("Verify the available Headers of Archive Forecast Table");
			// Verifying the Headers of Archive Forecasts Window
			ensureVisibilityOf(dash.getElementOfGivenText("Archive Forecast"), "Archive Forecast");
			// Verifying pagination/Navigation items of the Archive Forecast Windows
			verifyValueOf(dash.ForecastNameHeader_ArchiveForecast,   "innerText", "Forecast Name", 	"ForecastName Header under 'Archive Forecast' table");
			verifyValueOf(dash.ForecastTypeHeader_ArchiveForecast,   "innerText", "Forecast Type", 	"Forecast Type Header under 'Archive Forecast' table");
			verifyValueOf(dash.ForecastPeriodHeader_ArchiveForecast, "innerText", "Forecast Period",			"Period Header under 'Archive Forecast' table");
			verifyValueOf(dash.CreateDateHeader_ArchiveForecast,     "innerText", "Create Date","CreateDate Header under 'Archive Forecast' table");
			verifyValueOf(dash.CreatedByHeader_ArchiveForecast,      "innerText", "Created By", "CreatedBy Header under 'Archive Forecast' table");
			verifyValueOf(dash.ArchiveDateHeader_ArchiveForecast,     "innerText", "Archive Date","Archive Date Header under 'Archive Forecast' table");
			verifyValueOf(dash.CommentHeader_ArchiveForecast, 		 "innerText", "Comment", 		"Comment Header under 'Archive Forecast' table");
			verifyValueOf(dash.CloneHeader_ArchiveForecast, 		 "innerText", "Clone", 	"Clone Header under 'Archive Forecast' table");

			ExtentTestManager.endTest();
			driver.quit();

		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		} finally {
			ExtentTestManager.endTest();
			driver.quit();
		}

	}

	@Test(description="Not associated with group", enabled = true)
	public void TC3_TC6_NotAassociatedWithGroup() {
		// Anandhvidya to Rajuddin: You can leave this.
		// Got the user credentials 
		
		try {
			driver = TestBase.setDriver(browser, appURL);
			LoginScreen login = new LoginScreen();
			login.getLogin(noGroupUserName, noGroupPass);
			
			ExecutionLog.log("****************************************");
			ExecutionLog.log("URL:	" + appURL);
			ExecutionLog.log("Logged-In with user(Not Having Any Group Access): " + noGroupUserName);
			ExecutionLog.log("****************************************");
			
			ensureVisibilityOf(getElement("//p[text()='You do not belong to any group.']"), "Error Line#1: You do not belong to any group.");
			ensureVisibilityOf(getElement("//p[text()='Please contact the group administrator to get access.']"), "Error Line#2: Please contact the group administrator to get access.");
			ExtentTestManager.endTest();
			driver.quit();

		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		} finally {
			ExtentTestManager.endTest();
			driver.quit();
		}

			
	}

	@Test(description="Non-Admin leaves the group", groups="Regression", enabled = false)
	public void TC4_NonAdminLeavesTheGroup() {
		// Rajuddin: Can not automate as we need to make the user permission from backend
		// Rajuddin and Vidya Discussion on 12th Nov: 
		// 		We should do R&D on Retrieving the data from DB. If it is possible.
	}



}
