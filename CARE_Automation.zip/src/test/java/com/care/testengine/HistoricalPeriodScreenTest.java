package com.care.testengine;

import static com.care.utility.CommonMethods.*;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.care.reporting.ExecutionLog;
import com.care.reporting.ExtentTestManager;
import com.care.reporting.ReportScreenshot;
import static com.care.screens.CommonScreen.*;
import com.care.screens.DashboardScreen;
import com.care.screens.HistoricalPeriodScreen;
import com.care.screens.LoginScreen;
import com.care.test.base.TestBase;
import com.relevantcodes.extentreports.LogStatus;

public class HistoricalPeriodScreenTest extends TestBase {
	
	String forecast_CreatedBy_adminUserName 	= "Rajuddin_08Nov";//"AUT_Forecast_adminUserName" + DateTimeHelper.getCurrentDateTime();
	
	@Test(description="Admin should see Associate Group", groups="Regression", enabled = true)
	public void a() {
		TC1();
		
	}
	@Test(description="Admin should see Associate Group", groups="Regression", enabled = true)
	public void TC1() {

		ExtentTestManager.startTest("TC1-Admin should see Associate Group");

		try {
			driver = TestBase.setDriver(browser, appURL);
			LoginScreen login = new LoginScreen();
			login.getLogin(adminUserName, adminPass);
			
			ExecutionLog.log("****************************************");
			ExecutionLog.log("URL:	" + appURL);
			ExecutionLog.log("Logged-In with Admin user: " + adminUserName);
			ExecutionLog.log("****************************************");
			
			DashboardScreen dashbaord = new DashboardScreen();
			dashbaord.searchForecast(forecast_CreatedBy_adminUserName, adminUserName);
			HistoricalPeriodScreen history= new HistoricalPeriodScreen();
			clickOn(history.historicalPeriod,  "Historical Period Menu");			
			waitForSpinnerToDisappear();
			history.noteFunctionalities();
			
		} catch (Exception e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		}  catch (AssertionError e) {
			e.printStackTrace();
			ExtentTestManager.getTest().log(LogStatus.FAIL, e);
			ReportScreenshot.captureAndDisplayScreenShots(driver);
			Assert.fail();

		} finally {
			ExtentTestManager.endTest();
			driver.quit();
		}
	
	}

}
