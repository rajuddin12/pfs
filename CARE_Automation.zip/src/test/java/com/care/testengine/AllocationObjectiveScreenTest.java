package com.care.testengine;

import static com.care.utility.CommonMethods.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static com.care.screens.CommonScreen.*;
import org.testng.annotations.Test;

import com.care.excel.operations.ExcelWriter;
import com.care.excel.operations.ReadExcel;
import com.care.reporting.ExecutionLog;
import com.care.screens.AllocationObjectiveScreen;
import com.care.screens.CommonScreen;
import com.care.screens.CreateForecastScreen;
import com.care.screens.DashboardScreen;
import com.care.screens.LoginScreen;
import com.care.test.base.TestBase;

public class AllocationObjectiveScreenTest extends TestBase {

	
	AllocationObjectiveScreen allocationObjective;
	
//	String forecast_CreatedBy_adminUserName = "AUT_MultiplierTest_2019-01-02_15-06-22";
	
//	
//	@Test(priority=1, groups="Regression", enabled = true, description="TC1_To_TC4 Verify Allocation Screen Header")
//	public void  ExcelRead() throws Exception {
//		
//		String filePath = System.getProperty("user.dir") + File.separator + "\\R-squared.xlsx";
//		
//		browser				= ReadExcel.getCellData(2, 2, "CDV ", filePath);
//		System.out.println(browser);
//		
//		
//		ExcelWriter.setCellData("123", 2,2, "CDV ", filePath);
//		browser				= ReadExcel.getCellData(2, 2, "CDV ", filePath);
//		System.out.println(browser);
//		System.out.println(browser);
//		
//	}
		
//	@Test(priority=1, groups="Regression", enabled = true, description="TC1_To_TC4 Verify Allocation Screen Header")
	public void  a() throws Exception {
		
		driver = TestBase.setDriver(browser, appURL);
		LoginScreen login = new LoginScreen();
		login.getLogin(adminUserName, adminPass);
		
		ExecutionLog.log("****************************************");
		ExecutionLog.log("*URL:	" + appURL);
		ExecutionLog.log("*Logged-In with Admin user: " + adminUserName);
		ExecutionLog.log("****************************************");
		
//		CreateForecastScreen createForecast = new CreateForecastScreen();
//		createForecast.createForecast(forecast_CreatedBy_adminUserName);

		ExecutionLog.log("");
		ExecutionLog.log("******************Dashboard Screen******************");
		DashboardScreen dash = new DashboardScreen();
		
		dash.searchForecast(forecast_CreatedBy_adminUserName, adminUserName);
		dash.selectForecast(forecast_CreatedBy_adminUserName);
	
		
		TC1_To_TC4_VerifyAllocationScreenHeader();
		
	}
	
	
	@Test(description="TC1_To_TC4 Verify Allocation Screen Header", groups="Regression", enabled = true)
	public void TC1_To_TC4_VerifyAllocationScreenHeader() {
		try {
			
			
			driver = TestBase.setDriver(browser, appURL);
			LoginScreen login = new LoginScreen();
			login.getLogin(adminUserName, adminPass);
			
			ExecutionLog.log("****************************************");
			ExecutionLog.log("*URL:	" + appURL);
			ExecutionLog.log("*Logged-In with Admin user: " + adminUserName);
			ExecutionLog.log("****************************************");
			
//			
//			CreateForecastScreen.startMonth_value = new CreateForecastScreen().getCurrentMonth().substring(0, 3);
//			CreateForecastScreen.startYear_value = new CreateForecastScreen().getCurrentMonth().substring(3, 7);
//			CreateForecastScreen.endMonth_value = new CreateForecastScreen().getCurrentMonthPlus2Month().substring(0, 3);
//			CreateForecastScreen.endYear_value = new CreateForecastScreen().getCurrentMonthPlus2Month().substring(3, 7);
//			
//			
			clickOn(getElement("(//span[contains(@class,'ddmenuicon')])[2]"), "Expand CapacityPlanning");
			allocationObjective = new AllocationObjectiveScreen();
			clickOn(allocationObjective.allocationObjective, "Allocation Objective");
			waitForSpinnerToDisappear();	
			CommonScreen.verifyActiveBreadcumNavigation("Allocation Objective");
			
//			Query-1: Division and Region are shown separate fields whereas they have been merged on Create Forecast Screen
//			Query-2: The html code for all the header of each screen of Capacity Planning is under "th" tag not as of other screens of forecast
			
			
			
			verifyForcastName(forecast_CreatedBy_adminUserName);
			
			verifyForcastInfoAtScreenHeader("Base", getMonthNumberFromString(CreateForecastScreen.startMonth_value) + "/" + CreateForecastScreen.startYear_value + " - " + getMonthNumberFromString(CreateForecastScreen.endMonth_value) + "/" + CreateForecastScreen.endYear_value, "CENTRAL", "CHICAGO", "PHONE");
		} catch (Exception e) {
			e.printStackTrace();
			ExecutionLog.log("test");
		}
		// Sent Query to Vidya
//		List<String> expectedData = new ArrayList<String>();
//		expectedData.add("CABLE CARD");
//		expectedData.add("CDV");
//		expectedData.add("HSD");
//		expectedData.add("VIDEO");
//		equalLists(getAllDropDownValues(getElement("top_panel_call_type_select")), expectedData, "Call Type");
//		if(getElement("top_panel_call_type_select").getAttribute("multiple")==null) {
//			ExecutionLog.log("Call type is single drop down");
//		} else ExecutionLog.log("[Failed]: Call type is NOT single drop down");
	}
	
	
	
	
	
}
